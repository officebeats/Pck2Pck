import React, { useState, useRef, useEffect } from 'react';
import clsx from 'clsx';

export interface Comment {
  id: number;
  user: string;
  avatar?: string;
  text: string;
  timestamp: string;
  isMe: boolean;
}

interface CommentModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  comments: Comment[];
  onAddComment: (text: string) => void;
  onEditComment?: (id: number, newText: string) => void;
}

export default function CommentModal({ isOpen, onClose, title, comments, onAddComment, onEditComment }: CommentModalProps) {
  const [newComment, setNewComment] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const commentsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [isOpen, comments]);

  const handleSend = () => {
    if (!newComment.trim()) return;
    onAddComment(newComment);
    setNewComment('');
  };

  const startEditing = (comment: Comment) => {
    setEditingId(comment.id);
    setEditText(comment.text);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditText('');
  };

  const saveEdit = (id: number) => {
    if (onEditComment && editText.trim()) {
        onEditComment(id, editText);
    }
    setEditingId(null);
    setEditText('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center bg-slate-900/60 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
        <div className="neo-card w-full max-w-md h-[80vh] sm:h-[600px] flex flex-col transform transition-transform animate-slide-up sm:animate-none overflow-hidden bg-background-light dark:bg-background-dark">
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-card-dark">
                <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-slate-500">forum</span>
                    <div className="overflow-hidden">
                        <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight truncate">Comments</h3>
                        <p className="text-xs text-slate-500 truncate max-w-[200px]">{title}</p>
                    </div>
                </div>
                <button 
                    onClick={onClose}
                    className="neo-btn rounded-full p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                >
                    <span className="material-symbols-outlined">close</span>
                </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-background-light dark:bg-background-dark">
                {comments.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-500 opacity-60">
                        <span className="material-symbols-outlined text-4xl mb-2">chat_bubble_outline</span>
                        <p className="text-sm">No comments yet.</p>
                        <p className="text-xs">Start the discussion!</p>
                    </div>
                ) : (
                    comments.map((comment) => (
                        <div key={comment.id} className={clsx("flex gap-3 max-w-[90%]", comment.isMe ? "ml-auto flex-row-reverse" : "")}>
                            {!comment.isMe && (
                                <div className="size-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0 overflow-hidden">
                                    {comment.avatar ? (
                                        <img src={comment.avatar} alt={comment.user} className="size-full object-cover" />
                                    ) : (
                                        <span className="text-xs font-bold text-slate-500">{comment.user[0]}</span>
                                    )}
                                </div>
                            )}
                            
                            <div className={clsx("flex flex-col gap-1 min-w-0", comment.isMe ? "items-end" : "items-start")}>
                                {editingId === comment.id ? (
                                    <div className="flex flex-col items-end gap-2 w-full min-w-[200px]">
                                         <input 
                                            value={editText}
                                            onChange={(e) => setEditText(e.target.value)}
                                            onKeyDown={(e) => e.key === 'Enter' && saveEdit(comment.id)}
                                            className="w-full p-3 rounded-2xl text-sm border border-primary focus:outline-none text-slate-900 dark:text-white bg-white dark:bg-card-dark shadow-md"
                                            autoFocus
                                         />
                                         <div className="flex gap-2">
                                             <button onClick={cancelEditing} className="text-xs font-bold text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">Cancel</button>
                                             <button onClick={() => saveEdit(comment.id)} className="text-xs font-bold text-primary hover:text-primary/80">Save</button>
                                         </div>
                                    </div>
                                ) : (
                                    <>
                                        <div className={clsx(
                                            "px-4 py-2 rounded-2xl text-sm leading-relaxed shadow-sm break-words",
                                            comment.isMe 
                                                ? "bg-primary text-white rounded-br-none" 
                                                : "bg-white dark:bg-card-dark text-slate-800 dark:text-white rounded-bl-none border border-gray-100 dark:border-gray-700"
                                        )}>
                                            <p>{comment.text}</p>
                                        </div>
                                        <div className={clsx("flex items-center gap-2 px-1", comment.isMe ? "flex-row-reverse" : "flex-row")}>
                                            <span className="text-[10px] text-gray-400 dark:text-gray-500">{comment.timestamp}</span>
                                            {comment.isMe && onEditComment && (
                                                <button 
                                                    onClick={() => startEditing(comment)} 
                                                    className="text-[10px] font-bold text-slate-400 hover:text-primary transition-colors cursor-pointer"
                                                >
                                                    Edit
                                                </button>
                                            )}
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                    ))
                )}
                <div ref={commentsEndRef}></div>
            </div>

            <div className="p-3 bg-white dark:bg-card-dark border-t border-gray-200 dark:border-gray-700">
                <div className="flex gap-2 items-center">
                    <input 
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Type a message..."
                        className="neo-inset flex-1 rounded-full px-4 py-3 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50 bg-background-light dark:bg-background-dark"
                    />
                    <button 
                        onClick={handleSend}
                        disabled={!newComment.trim()}
                        className="neo-btn-primary flex items-center justify-center rounded-full size-11 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg"
                    >
                        <span className="material-symbols-outlined text-xl">send</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
}