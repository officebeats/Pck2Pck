import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import CommentModal, { Comment } from '../components/CommentModal';

// --- Types & Interfaces ---

/** Supported color themes for UI elements */
type ColorTheme = 'blue' | 'purple' | 'emerald' | 'amber';

/** Represents a pay cycle bucket */
interface Paycheck {
  id: string;
  date: Date;
  label: string;
  amount: number;
  color: ColorTheme;
}

/** Represents a bill item within the planning view */
interface Bill {
  id: number;
  name: string;
  companyName?: string;
  amount: number;
  dueDate: Date; // Use string for JSON storage, convert back to Date in component
  assignedPaycheckId: string;
  icon: string;
  frequency: string;
  dueDay?: number;
  dueMonth?: number;
  dueDayOfWeek?: string;
  category?: string;
  color?: string;
  reminder?: {
    enabled: boolean;
    daysBefore: number;
    time: string;
  };
  website?: string;
  username?: string;
  password?: string;
  accountNumber?: string;
  notes?: string;
  comments?: Comment[];
}

// --- Constants & Helpers ---

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Returns number with ordinal suffix (e.g., 1st, 2nd, 3rd) */
const getOrdinal = (n: number): string => {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

/** Visual styles configuration map */
const THEME_STYLES: Record<ColorTheme, { 
    bg: string; 
    text: string; 
    dot: string; 
    border: string; 
    softBg: string; 
    hoverBorder: string;
    bucketBg: string;
    placeholderBorder: string;
    placeholderBg: string;
}> = {
  blue: { 
      bg: 'bg-blue-600', 
      text: 'text-blue-700 dark:text-blue-300', 
      dot: 'bg-blue-500', 
      border: 'border-blue-300 dark:border-blue-700', 
      softBg: 'bg-blue-100 dark:bg-blue-900/30',
      hoverBorder: 'border-blue-500',
      bucketBg: 'bg-blue-50/50 dark:bg-blue-900/10',
      placeholderBorder: 'border-blue-400/50',
      placeholderBg: 'bg-blue-400/10'
  },
  purple: { 
      bg: 'bg-purple-600', 
      text: 'text-purple-700 dark:text-purple-300', 
      dot: 'bg-purple-500', 
      border: 'border-purple-300 dark:border-purple-700', 
      softBg: 'bg-purple-100 dark:bg-purple-900/30',
      hoverBorder: 'border-purple-500',
      bucketBg: 'bg-purple-50/50 dark:bg-purple-900/10',
      placeholderBorder: 'border-purple-400/50',
      placeholderBg: 'bg-purple-400/10'
  },
  emerald: { 
      bg: 'bg-emerald-600', 
      text: 'text-emerald-700 dark:text-emerald-300', 
      dot: 'bg-emerald-500', 
      border: 'border-emerald-300 dark:border-emerald-700', 
      softBg: 'bg-emerald-100 dark:bg-emerald-900/30',
      hoverBorder: 'border-emerald-500',
      bucketBg: 'bg-emerald-50/50 dark:bg-emerald-900/10',
      placeholderBorder: 'border-emerald-400/50',
      placeholderBg: 'bg-emerald-400/10'
  },
  amber: {
      bg: 'bg-amber-600', 
      text: 'text-amber-700 dark:text-amber-300', 
      dot: 'bg-amber-500', 
      border: 'border-amber-300 dark:border-amber-700', 
      softBg: 'bg-amber-100 dark:bg-amber-900/30',
      hoverBorder: 'border-amber-500',
      bucketBg: 'bg-amber-50/50 dark:bg-amber-900/10',
      placeholderBorder: 'border-amber-400/50',
      placeholderBg: 'bg-amber-400/10'
  }
};

const MOCK_PLANNING_BILLS: Bill[] = [
    { id: 1, name: 'Rent', companyName: 'Landlord Co', amount: 1800, dueDate: new Date(2023, 9, 1), assignedPaycheckId: 'p1', icon: 'house', frequency: 'Monthly', dueDay: 1, category: 'Housing', color: 'blue', notes: 'Check sent via mail', comments: [] },
    { id: 2, name: 'Spotify', companyName: 'Spotify', website: 'https://spotify.com/account', amount: 15, dueDate: new Date(2023, 9, 15), assignedPaycheckId: 'p1', icon: 'music_note', frequency: 'Monthly', dueDay: 15, category: 'Entertainment', color: 'green', comments: [] },
    { id: 3, name: 'Internet', companyName: 'Xfinity', website: 'https://xfinity.com', amount: 90, dueDate: new Date(2023, 9, 18), assignedPaycheckId: 'p1', icon: 'wifi', frequency: 'Monthly', dueDay: 18, category: 'Utilities', color: 'purple', comments: [] },
    { id: 4, name: 'Mortgage', companyName: 'Rocket Mortgage', amount: 1500, dueDate: new Date(2023, 9, 25), assignedPaycheckId: 'p2', icon: 'house', frequency: 'Monthly', dueDay: 25, category: 'Housing', color: 'blue', comments: [] },
    { id: 5, name: 'Electricity', amount: 145, dueDate: new Date(2023, 9, 28), assignedPaycheckId: 'p2', icon: 'bolt', frequency: 'Monthly', dueDay: 28, category: 'Utilities', color: 'orange', comments: [] },
    { id: 6, name: 'Car Payment', companyName: 'Toyota Financial', amount: 350, dueDate: new Date(2023, 9, 30), assignedPaycheckId: 'p2', icon: 'directions_car', frequency: 'Monthly', dueDay: 30, category: 'Transport', color: 'red', comments: [] },
];

export default function Planning() {
  const navigate = useNavigate();
  
  // --- State ---
  const [viewMode, setViewMode] = useState<'allocations' | 'list'>('allocations');
  
  // Drag and Drop State
  const [draggedBillId, setDraggedBillId] = useState<number | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  // Modal & Interaction State
  const [discussingBillId, setDiscussingBillId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'view' | 'edit'>('view');
  const [isDayPickerOpen, setIsDayPickerOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    amount: '',
    frequency: 'Monthly',
    category: '',
    icon: 'receipt',
    dueDay: 1,
    dueMonth: 0,
    dueDayOfWeek: 'Monday',
    website: '',
    username: '',
    password: '',
    accountNumber: '',
    notes: ''
  });

  // --- Mock Data ---
  const paychecks: Paycheck[] = useMemo(() => [
    { id: 'p1', date: new Date(2023, 9, 13), label: 'Oct #1', amount: 2250, color: 'blue' },
    { id: 'p2', date: new Date(2023, 9, 27), label: 'Oct #2', amount: 2450, color: 'purple' },
  ], []);

  // --- Persistent State for Bills ---
  const [bills, setBills] = useState<Bill[]>(() => {
      const saved = localStorage.getItem('pchk_planning_bills');
      if (saved) {
          try {
              const parsed = JSON.parse(saved);
              // Hydrate date strings back to Date objects
              return parsed.map((b: any) => ({
                  ...b,
                  dueDate: new Date(b.dueDate)
              }));
          } catch(e) {
              console.error(e);
          }
      }
      return MOCK_PLANNING_BILLS;
  });

  useEffect(() => {
      localStorage.setItem('pchk_planning_bills', JSON.stringify(bills));
  }, [bills]);

  // --- Handlers ---

  /**
   * Moves a bill to a specific paycheck bucket.
   */
  const moveBill = useCallback((billId: number, targetPaycheckId: string) => {
    setBills(prev => prev.map(b => b.id === billId ? { ...b, assignedPaycheckId: targetPaycheckId } : b));
  }, []);

  // --- Drag and Drop Logic ---

  const handleDragStart = (e: React.DragEvent, billId: number) => {
      setDraggedBillId(billId);
      // 'move' indicates that the element is being moved, not copied
      e.dataTransfer.effectAllowed = 'move';
      // Optional: Set a drag image or custom styling here
  };

  const handleDragOver = (e: React.DragEvent, paycheckId: string) => {
      e.preventDefault(); // Necessary to allow dropping
      e.dataTransfer.dropEffect = 'move';
      
      // Update dragOverId only if it changes to prevent excessive re-renders
      if (dragOverId !== paycheckId) {
          setDragOverId(paycheckId);
      }
  };

  const handleDragLeave = (e: React.DragEvent) => {
      e.preventDefault();
      // Logic to detect leaving the container vs entering a child element
      // This basic check helps prevents flickering
      if (e.currentTarget.contains(e.relatedTarget as Node)) {
          return;
      }
      setDragOverId(null);
  };

  const handleDrop = (e: React.DragEvent, targetPaycheckId: string) => {
      e.preventDefault();
      setDragOverId(null); // Reset hover state
      
      if (draggedBillId !== null) {
          moveBill(draggedBillId, targetPaycheckId);
          setDraggedBillId(null);
      }
  };

  // --- Modal Logic ---

  const handleOpenModal = (bill?: Bill) => {
    setIsDayPickerOpen(false);
    if (bill) {
      setEditingId(bill.id);
      setModalMode('view');
      setFormData({
        name: bill.name,
        companyName: bill.companyName || '',
        amount: bill.amount.toString(),
        frequency: bill.frequency,
        category: bill.category || '',
        icon: bill.icon,
        dueDay: bill.dueDay || 1,
        dueMonth: bill.dueMonth || bill.dueDate.getMonth(),
        dueDayOfWeek: bill.dueDayOfWeek || 'Monday',
        website: bill.website || '',
        username: bill.username || '',
        password: bill.password || '',
        accountNumber: bill.accountNumber || '',
        notes: bill.notes || ''
      });
    } else {
      setEditingId(null);
      setModalMode('edit');
      setFormData({
        name: '',
        companyName: '',
        amount: '',
        frequency: 'Monthly',
        category: '',
        icon: 'receipt',
        dueDay: 1,
        dueMonth: 0,
        dueDayOfWeek: 'Monday',
        website: '',
        username: '',
        password: '',
        accountNumber: '',
        notes: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSaveBill = () => {
    if (!formData.name || !formData.amount) return;
    const numAmount = parseFloat(formData.amount);
    
    // Calculate Due Date based on Frequency
    const today = new Date();
    let dueDate = new Date();
    if (formData.frequency === 'Monthly') {
        dueDate = new Date(today.getFullYear(), today.getMonth(), formData.dueDay);
        if (dueDate < today) dueDate.setMonth(dueDate.getMonth() + 1);
    } else if (formData.frequency === 'Yearly') {
        dueDate = new Date(today.getFullYear(), formData.dueMonth, formData.dueDay);
        if (dueDate < today) dueDate.setFullYear(dueDate.getFullYear() + 1);
    } else {
        dueDate.setDate(today.getDate() + 7);
    }

    const newBillData = {
        name: formData.name,
        companyName: formData.companyName,
        amount: numAmount,
        frequency: formData.frequency,
        dueDate: dueDate,
        category: formData.category,
        icon: formData.icon,
        dueDay: formData.dueDay,
        dueMonth: formData.dueMonth,
        dueDayOfWeek: formData.dueDayOfWeek,
        website: formData.website,
        username: formData.username,
        password: formData.password,
        accountNumber: formData.accountNumber,
        notes: formData.notes,
        color: 'blue', 
    };

    if (editingId) {
        setBills(bills.map(b => b.id === editingId ? { ...b, ...newBillData } : b));
    } else {
        setBills([...bills, {
            id: Date.now(),
            assignedPaycheckId: paychecks[0].id,
            comments: [],
            ...newBillData
        }]);
    }
    setIsModalOpen(false);
  };

  const handleDeleteBill = () => {
      if (editingId) {
          setBills(bills.filter(b => b.id !== editingId));
          setIsModalOpen(false);
      }
  };

  const handleAddComment = (text: string) => {
    if (!discussingBillId) return;
    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      text,
      timestamp: 'Just now',
      isMe: true
    };
    setBills(prev => prev.map(b => b.id === discussingBillId ? { ...b, comments: [...(b.comments || []), newComment] } : b));
  };

  const discussingBill = bills.find(b => b.id === discussingBillId);

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark text-slate-900 dark:text-white font-sans transition-colors duration-200">
      
      {/* Header */}
      <div className="sticky top-0 z-20 flex flex-col bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 transition-colors">
        <div className="flex items-center p-3 pb-2 justify-between">
            <div className="flex items-center gap-2">
                <button onClick={() => navigate(-1)} className="text-slate-800 dark:text-white flex size-9 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                    <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold leading-tight">Bills & Planning</h1>
            </div>
            <button 
                onClick={() => handleOpenModal()}
                className="neo-btn-primary size-9 flex items-center justify-center rounded-full shadow-lg active:scale-95 transition-all"
            >
                <span className="material-symbols-outlined text-xl">add</span>
            </button>
        </div>

        {/* View Mode Tabs */}
        <div className="px-4 pb-3">
             <div className="neo-inset flex p-1 gap-1">
                 <button 
                    onClick={() => setViewMode('allocations')}
                    className={clsx(
                        "flex-1 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all",
                        viewMode === 'allocations' 
                            ? "bg-white dark:bg-card-dark text-primary shadow-sm" 
                            : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    )}
                 >
                     <span className="material-symbols-outlined text-sm">drag_indicator</span>
                     Allocations
                 </button>
                 <button 
                    onClick={() => setViewMode('list')}
                    className={clsx(
                        "flex-1 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all",
                        viewMode === 'list' 
                            ? "bg-white dark:bg-card-dark text-primary shadow-sm" 
                            : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    )}
                 >
                     <span className="material-symbols-outlined text-sm">list</span>
                     All Bills
                 </button>
             </div>
        </div>
      </div>

      <main className="flex-1 p-4 md:p-6 pb-24 space-y-6">
        {/* Allocations View (Drag & Drop) */}
        {viewMode === 'allocations' && (
            <div className="space-y-4 animate-fade-in">
                {paychecks.map((paycheck) => {
                    const assignedBills = bills.filter(b => b.assignedPaycheckId === paycheck.id);
                    const totalAssigned = assignedBills.reduce((acc, b) => acc + b.amount, 0);
                    const safeSpend = paycheck.amount - totalAssigned;
                    const theme = THEME_STYLES[paycheck.color];
                    const isHovered = dragOverId === paycheck.id;

                    return (
                        <div 
                            key={paycheck.id} 
                            className={clsx(
                                "neo-card overflow-hidden transition-all duration-300", 
                                theme.bucketBg, 
                                isHovered ? `border-2 ${theme.hoverBorder}` : theme.border
                            )}
                            onDragOver={(e) => handleDragOver(e, paycheck.id)}
                            onDragLeave={handleDragLeave}
                            onDrop={(e) => handleDrop(e, paycheck.id)}
                        >
                            {/* Bucket Header */}
                            <div className={clsx("p-3 border-b flex justify-between items-center transition-colors", theme.border, "bg-white/40 dark:bg-black/20")}>
                                <div className="flex items-center gap-3">
                                    <div className={clsx("size-8 rounded-full flex items-center justify-center text-white shadow-sm", theme.bg)}>
                                        <span className="font-bold text-[10px]">{paycheck.label.split('#')[1]}</span>
                                    </div>
                                    <div>
                                        <h4 className={clsx("font-bold text-sm", theme.text)}>{paycheck.label}</h4>
                                        <p className="text-[10px] text-slate-500 font-mono">{paycheck.date.toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wide">Safe Spend</p>
                                    <p className={clsx("text-base font-bold", safeSpend < 0 ? "text-red-500" : "text-slate-900 dark:text-white")}>${safeSpend.toLocaleString()}</p>
                                </div>
                            </div>

                            {/* Droppable Area */}
                            <div className="p-2 min-h-[80px] space-y-2 relative">
                                {assignedBills.length === 0 && !isHovered && (
                                    <div className="flex flex-col items-center justify-center py-4 text-center opacity-40">
                                        <span className="material-symbols-outlined text-2xl">input</span>
                                        <p className="text-[10px] font-bold uppercase mt-1">Drag bills here</p>
                                    </div>
                                )}

                                {assignedBills.map(bill => {
                                    const isRisky = bill.dueDate < paycheck.date;
                                    const isBeingDragged = draggedBillId === bill.id;
                                    
                                    return (
                                        <div 
                                            key={bill.id} 
                                            draggable 
                                            onDragStart={(e) => handleDragStart(e, bill.id)} 
                                            onClick={() => handleOpenModal(bill)}
                                            className={clsx(
                                                "neo-card p-2 flex items-center gap-2 group relative cursor-grab active:cursor-grabbing hover:translate-x-1 transition-all bg-white dark:bg-card-dark select-none", 
                                                isRisky ? "border-red-300 dark:border-red-800" : "border-slate-200 dark:border-slate-700",
                                                isBeingDragged ? "opacity-50" : "opacity-100"
                                            )}
                                        >
                                            {isRisky && <div className="absolute left-0 top-0 bottom-0 w-1 bg-red-500 rounded-l-lg"></div>}
                                            <div className={clsx("size-7 rounded-full flex items-center justify-center shrink-0", theme.softBg, theme.text)}>
                                                <span className="material-symbols-outlined text-sm">{bill.icon}</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <p className="font-bold text-xs text-slate-900 dark:text-white truncate">{bill.name}</p>
                                                </div>
                                                <p className="text-[10px] text-slate-500 dark:text-slate-400">Due {bill.dueDate.toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="font-bold text-xs text-slate-900 dark:text-white">${bill.amount.toFixed(0)}</p>
                                            </div>
                                        </div>
                                    );
                                })}
                                
                                {isHovered && (
                                    <div className={clsx("absolute inset-2 border-2 border-dashed rounded-xl flex items-center justify-center z-10 pointer-events-none", theme.placeholderBorder, theme.placeholderBg)}>
                                        <span className={clsx("font-bold text-xs", theme.text)}>Drop here</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        )}

        {/* List View */}
        {viewMode === 'list' && (
            <div className="space-y-2 animate-fade-in">
                {bills.sort((a,b) => a.dueDate.getTime() - b.dueDate.getTime()).map(bill => (
                    <div 
                        key={bill.id} 
                        onClick={() => handleOpenModal(bill)}
                        className="neo-card p-3 flex items-center gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                        <div className="neo-inset flex items-center justify-center size-10 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            <span className="material-symbols-outlined text-lg">{bill.icon}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-center mb-0.5">
                                <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">{bill.name}</h4>
                                <span className="font-bold text-sm text-slate-900 dark:text-white">${bill.amount.toFixed(0)}</span>
                            </div>
                            <div className="flex justify-between items-center text-xs text-slate-500 dark:text-slate-400">
                                <span>Due {bill.dueDate.toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}</span>
                                <span className="text-[10px] uppercase font-bold tracking-wide bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded">{bill.category}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        )}
      </main>

      {/* Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center bg-slate-900/60 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
          <div className="neo-card w-full max-w-sm max-h-[90vh] overflow-y-auto transform transition-transform animate-slide-up sm:animate-none p-6">
            
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {modalMode === 'view' ? 'Bill Details' : (editingId ? 'Edit Bill' : 'New Bill')}
              </h2>
              <div className="flex items-center gap-2">
                  {modalMode === 'view' && (
                      <>
                        <button onClick={() => setDiscussingBillId(editingId)} className="neo-btn rounded-full p-2 text-gray-500 hover:text-primary transition-colors">
                            <span className="material-symbols-outlined">chat_bubble_outline</span>
                        </button>
                        <button onClick={() => setModalMode('edit')} className="neo-btn rounded-full p-2 text-primary hover:text-primary/80">
                            <span className="material-symbols-outlined">edit</span>
                        </button>
                      </>
                  )}
                  <button onClick={() => setIsModalOpen(false)} className="neo-btn rounded-full p-2 text-gray-500">
                    <span className="material-symbols-outlined">close</span>
                  </button>
              </div>
            </div>

            {modalMode === 'view' ? (
                <div className="space-y-6">
                    <div className="flex flex-col items-center justify-center py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-black/20 rounded-xl neo-inset">
                        <p className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">${parseFloat(formData.amount).toFixed(2)}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">{formData.companyName || formData.name}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                        <div className="neo-card p-3 flex flex-col items-center">
                            <span className="text-[10px] text-slate-400 uppercase font-bold">Frequency</span>
                            <span className="text-sm font-bold text-slate-900 dark:text-white">{formData.frequency}</span>
                        </div>
                        <div className="neo-card p-3 flex flex-col items-center">
                            <span className="text-[10px] text-slate-400 uppercase font-bold">Due Date</span>
                            <span className="text-sm font-bold text-slate-900 dark:text-white">Day {formData.dueDay}</span>
                        </div>
                    </div>

                    {(formData.username || formData.accountNumber) && (
                        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl space-y-2 border border-gray-200 dark:border-gray-700">
                            <div className="flex items-center gap-2 mb-2">
                                <span className="material-symbols-outlined text-slate-400 text-lg">lock</span>
                                <span className="text-xs font-bold text-slate-500 uppercase">Shared Info</span>
                            </div>
                            {formData.accountNumber && (
                                <div className="flex justify-between text-xs">
                                    <span className="text-slate-500">Acct #</span>
                                    <span className="font-mono font-bold text-slate-900 dark:text-white">{formData.accountNumber}</span>
                                </div>
                            )}
                            {formData.username && (
                                <div className="flex justify-between text-xs">
                                    <span className="text-slate-500">User</span>
                                    <span className="font-mono font-bold text-slate-900 dark:text-white">{formData.username}</span>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            ) : (
                // Edit Form
                <div className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Name</label>
                        <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none" placeholder="Bill Name"/>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Amount</label>
                        <input type="number" value={formData.amount} onChange={(e) => setFormData({...formData, amount: e.target.value})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none" placeholder="0.00"/>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Frequency</label>
                            <div className="neo-inset px-2">
                                <select value={formData.frequency} onChange={(e) => setFormData({...formData, frequency: e.target.value})} className="neo-input w-full py-3 text-slate-900 dark:text-white text-sm font-medium bg-transparent border-none focus:outline-none">
                                    <option>Monthly</option>
                                    <option>Weekly</option>
                                    <option>Yearly</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Day Due</label>
                            <input type="number" min="1" max="31" value={formData.dueDay} onChange={(e) => setFormData({...formData, dueDay: parseInt(e.target.value)})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none"/>
                        </div>
                    </div>

                    <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                        <p className="text-xs font-bold text-slate-400 uppercase mb-3">Optional Details</p>
                        <div className="space-y-3">
                            <input type="text" value={formData.companyName} onChange={(e) => setFormData({...formData, companyName: e.target.value})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm focus:outline-none" placeholder="Company Name"/>
                            <input type="text" value={formData.accountNumber} onChange={(e) => setFormData({...formData, accountNumber: e.target.value})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm focus:outline-none" placeholder="Account Number"/>
                            <textarea value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm focus:outline-none resize-none h-20" placeholder="Notes..."></textarea>
                        </div>
                    </div>

                    <div className="mt-6 flex gap-3">
                        {editingId && (
                            <button onClick={handleDeleteBill} className="neo-btn px-4 py-3 rounded-xl text-red-600 dark:text-red-400 font-bold hover:bg-red-50 dark:hover:bg-red-900/20 text-sm">Delete</button>
                        )}
                        <div className="flex-1"></div>
                        <button onClick={handleSaveBill} className="neo-btn-primary px-6 py-3 rounded-xl font-bold text-sm">Save Bill</button>
                    </div>
                </div>
            )}
          </div>
        </div>
      )}

      {/* Discussion Modal */}
      <CommentModal 
        isOpen={!!discussingBill}
        onClose={() => setDiscussingBillId(null)}
        title={discussingBill?.name || 'Bill'}
        comments={discussingBill?.comments || []}
        onAddComment={handleAddComment}
      />
    </div>
  );
}