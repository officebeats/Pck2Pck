import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';

export default function Settings({ isDark, toggleTheme }: { isDark: boolean, toggleTheme: () => void }) {
  const navigate = useNavigate();
  const [name, setName] = useState('John Doe');
  const [email, setEmail] = useState('john.doe@example.com');
  const [avatar, setAvatar] = useState('https://cdn-icons-png.flaticon.com/512/149/149071.png');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  
  // Toggles
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
        try {
            const user = JSON.parse(storedUser);
            setName(user.name || 'User');
            setEmail(user.email || 'user@example.com');
            if (user.avatar) setAvatar(user.avatar);
        } catch(e) {
            console.error("Error parsing user info", e);
        }
    }
  }, []);

  const handleSignOut = () => {
      localStorage.removeItem('user');
      navigate('/');
  };

  const handleResetData = () => {
      if (window.confirm("Are you sure? This will delete all bills, chats, and income sources tracked on this device. This cannot be undone.")) {
          // Clear specific app keys
          const keysToRemove = [
              'user',
              'pchk_dashboard_bills',
              'pchk_planning_bills',
              'pchk_recurring_bills',
              'pchk_income_sources',
              'pchk_chats',
              'pchk_notifications',
              'pchk_bill_payments'
          ];
          keysToRemove.forEach(key => localStorage.removeItem(key));
          navigate('/');
      }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-sans transition-colors duration-200">
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between transition-colors md:p-6 md:pb-0 gap-3 border-b border-transparent">
        <button onClick={() => navigate(-1)} className="neo-btn flex size-9 shrink-0 items-center justify-center text-slate-800 dark:text-white rounded-full md:hidden">
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center md:text-left">Settings</h1>
        <div className="size-9 md:hidden"></div>
      </div>

      <main className="flex-1 p-4 md:p-6 space-y-6 pb-24">
        
        {/* Profile Section */}
        <section className="animate-fade-in">
            <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 px-1">Profile</h2>
            <div className="neo-card p-4 flex flex-col gap-4">
                <div className="flex items-center gap-4">
                    <div className="relative group cursor-pointer">
                        <img 
                            src={avatar} 
                            alt="Profile" 
                            className="size-16 rounded-full object-cover border-2 border-slate-100 dark:border-slate-700 shadow-sm"
                        />
                        <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="material-symbols-outlined text-white text-xl">edit</span>
                        </div>
                    </div>
                    <div className="flex-1 space-y-2">
                        <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase">Display Name</label>
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full bg-transparent border-b border-slate-200 dark:border-slate-700 py-1 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:border-primary"
                            />
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase">Email</label>
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-transparent border-b border-slate-200 dark:border-slate-700 py-1 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:border-primary"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        {/* App Preferences */}
        <section className="animate-fade-in delay-75">
            <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 px-1">App Settings</h2>
            <div className="neo-card overflow-hidden">
                <div 
                    onClick={toggleTheme}
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors border-b border-gray-100 dark:border-gray-700"
                >
                    <div className="flex items-center gap-3">
                        <div className="size-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300">
                            <span className="material-symbols-outlined text-lg">{isDark ? 'dark_mode' : 'light_mode'}</span>
                        </div>
                        <span className="text-sm font-bold text-slate-900 dark:text-white">Dark Mode</span>
                    </div>
                    <div className={clsx("w-10 h-6 rounded-full relative transition-colors", isDark ? "bg-primary" : "bg-slate-300")}>
                        <div className={clsx("absolute top-1 left-1 bg-white size-4 rounded-full shadow transition-transform", isDark ? "translate-x-4" : "")}></div>
                    </div>
                </div>

                <div className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-700">
                    <div className="flex items-center gap-3">
                        <div className="size-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300">
                            <span className="material-symbols-outlined text-lg">notifications</span>
                        </div>
                        <span className="text-sm font-bold text-slate-900 dark:text-white">Bill Reminders</span>
                    </div>
                    <button 
                        onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                        className={clsx("w-10 h-6 rounded-full relative transition-colors", notificationsEnabled ? "bg-primary" : "bg-slate-300")}
                    >
                        <div className={clsx("absolute top-1 left-1 bg-white size-4 rounded-full shadow transition-transform", notificationsEnabled ? "translate-x-4" : "")}></div>
                    </button>
                </div>

                <div 
                    onClick={() => navigate('/income')}
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                    <div className="flex items-center gap-3">
                        <div className="size-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-600">
                            <span className="material-symbols-outlined text-lg">attach_money</span>
                        </div>
                        <span className="text-sm font-bold text-slate-900 dark:text-white">Manage Income Sources</span>
                    </div>
                    <span className="material-symbols-outlined text-slate-400">chevron_right</span>
                </div>
            </div>
        </section>

        {/* Security */}
        <section className="animate-fade-in delay-100">
            <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 px-1">Security</h2>
            <div className="neo-card p-4 space-y-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Current Password</label>
                    <input 
                        type="password" 
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="••••••••"
                        className="neo-inset w-full p-3 rounded-lg text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">New Password</label>
                    <input 
                        type="password" 
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="••••••••"
                        className="neo-inset w-full p-3 rounded-lg text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                </div>
                <div className="pt-2">
                    <button className="neo-btn-primary px-4 py-2 rounded-lg text-sm font-bold w-full">Update Password</button>
                </div>
            </div>
        </section>

        {/* Data & Storage */}
        <section className="animate-fade-in delay-150">
            <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 px-1">Data & Storage</h2>
            <div className="neo-card p-4">
                <div className="flex items-center justify-between mb-3">
                    <div>
                        <p className="text-sm font-bold text-slate-900 dark:text-white">Local Data</p>
                        <p className="text-xs text-slate-500">Data is saved to this browser.</p>
                    </div>
                    <span className="material-symbols-outlined text-slate-400">sd_storage</span>
                </div>
                <button 
                    onClick={handleResetData}
                    className="w-full py-2.5 rounded-lg border border-red-200 dark:border-red-900/30 text-red-600 dark:text-red-400 text-xs font-bold hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors flex items-center justify-center gap-2"
                >
                    <span className="material-symbols-outlined text-sm">delete_forever</span>
                    Reset App Data
                </button>
            </div>
        </section>

        {/* Account Actions */}
        <section className="animate-fade-in delay-200 pt-2">
            <button onClick={handleSignOut} className="w-full py-3 text-slate-600 dark:text-slate-300 font-bold text-sm bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                Sign Out
            </button>
            <div className="text-center mt-4">
                <p className="text-[10px] text-slate-400">Version 1.2.0 • Build 2405</p>
            </div>
        </section>

      </main>
    </div>
  );
}