import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import CommentModal, { Comment } from '../components/CommentModal';

// --- Interfaces ---

/** Represents a Bill in the dashboard view */
interface Bill {
  id: number;
  name: string;
  amount: number;
  dueDate: string; // Changed to string for JSON serialization
  status: 'overdue' | 'due_soon' | 'due_today' | 'upcoming' | 'paid';
  icon: string;
  category: string;
  paycheckLabel: string; // e.g. 'Oct #2' or 'Nov #1'
  comments?: Comment[];
  // Shared Details
  companyName?: string;
  website?: string;
  username?: string;
  password?: string;
  accountNumber?: string;
  notes?: string;
}

interface TimerProps {
    targetDate: Date;
    status: string;
}

// --- Mock Data (Fallback) ---
const MOCK_BILLS: Bill[] = [
    { 
        id: 1, 
        name: 'Mortgage', 
        amount: 1500.00, 
        dueDate: '2023-10-25T00:00:00.000Z', 
        status: 'overdue', 
        icon: 'house', 
        category: 'Housing', 
        paycheckLabel: 'Oct #2', 
        comments: [],
        companyName: 'Rocket Mortgage',
        accountNumber: '9988776655',
        notes: 'Late fee applied if not paid by 5th'
    },
    { 
        id: 2, 
        name: 'Electricity', 
        amount: 145.20, 
        dueDate: '2023-10-26T00:00:00.000Z', 
        status: 'due_today', 
        icon: 'bolt', 
        category: 'Utilities', 
        paycheckLabel: 'Oct #2', 
        comments: [],
        companyName: 'City Power'
    },
    { 
        id: 3, 
        name: 'Car Payment', 
        amount: 350.00, 
        dueDate: '2023-10-28T00:00:00.000Z', 
        status: 'due_soon', 
        icon: 'directions_car', 
        category: 'Transport', 
        paycheckLabel: 'Oct #2', 
        comments: [],
        companyName: 'Toyota Financial',
        website: 'https://toyotafinancial.com',
        username: 'johndoe_car',
        password: 'securePassword123',
    },
    { 
        id: 4, 
        name: 'Internet', 
        amount: 89.99, 
        dueDate: '2023-10-29T00:00:00.000Z', 
        status: 'upcoming', 
        icon: 'wifi', 
        category: 'Utilities', 
        paycheckLabel: 'Oct #2', 
        comments: [],
        companyName: 'Xfinity',
        website: 'https://xfinity.com',
        username: 'fam_wifi',
        password: 'password!',
    },
    { 
        id: 5, 
        name: 'Netflix', 
        amount: 15.99, 
        dueDate: '2023-10-18T00:00:00.000Z', 
        status: 'paid', 
        icon: 'tv', 
        category: 'Entertainment', 
        paycheckLabel: 'Oct #2', 
        comments: [],
        website: 'https://netflix.com'
    },
    { 
        id: 6, 
        name: 'Gym', 
        amount: 35.00, 
        dueDate: '2023-11-01T00:00:00.000Z', 
        status: 'upcoming', 
        icon: 'fitness_center', 
        category: 'Health', 
        paycheckLabel: 'Nov #1', 
        comments: [],
        notes: 'New membership rate starts Nov'
    },
];

// --- Components ---

/**
 * CountdownTimer Component
 * Displays the time remaining until a bill is due.
 */
const CountdownTimer = ({ targetDate, status }: TimerProps) => {
  const [timeLeft, setTimeLeft] = useState<{d: number, h: number, m: number} | null>(null);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const target = targetDate.getTime();
      let diff = target - now;

      if (status === 'overdue') {
        diff = now - target;
      }

      if (diff < 0) diff = 0;

      setTimeLeft({
        d: Math.floor(diff / (1000 * 60 * 60 * 24)),
        h: Math.floor((diff / (1000 * 60 * 60)) % 24),
        m: Math.floor((diff / 1000 / 60) % 60),
      });
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 60000); // Update every minute to save resources
    return () => clearInterval(timer);
  }, [targetDate, status]);

  if (!timeLeft) return null;

  const isOverdue = status === 'overdue';
  
  return (
    <div className={clsx(
        "flex items-center gap-1 font-mono text-[10px] font-bold uppercase tracking-wider animate-fade-in",
        isOverdue ? "text-red-700 dark:text-red-400" : "text-orange-700 dark:text-orange-400"
    )}>
        <span className="material-symbols-outlined text-sm mb-[1px] animate-pulse">
            {isOverdue ? 'warning' : 'timer'}
        </span>
        <span className="truncate">
            {isOverdue ? 'LATE: ' : ''}{timeLeft.d}d {timeLeft.h.toString().padStart(2, '0')}h {timeLeft.m.toString().padStart(2, '0')}m
        </span>
    </div>
  );
};

export default function Home() {
  const navigate = useNavigate();
  
  // --- Constants ---
  const today = new Date('2023-10-26T09:00:00'); 
  const currentCycleLabel = 'Oct #2';

  // --- State ---
  const [currentBalance, setCurrentBalance] = useState(2450.00);
  
  // Load initial bills from localStorage or fallback to Mock Data
  const [bills, setBills] = useState<Bill[]>(() => {
      const saved = localStorage.getItem('pchk_dashboard_bills');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch (e) {
              console.error('Failed to load bills', e);
          }
      }
      return MOCK_BILLS;
  });

  // Persist bills on change
  useEffect(() => {
      localStorage.setItem('pchk_dashboard_bills', JSON.stringify(bills));
  }, [bills]);

  // Modal State
  const [confirmingBillId, setConfirmingBillId] = useState<number | null>(null);
  const [viewingDetailsBillId, setViewingDetailsBillId] = useState<number | null>(null);
  const [discussingBillId, setDiscussingBillId] = useState<number | null>(null);
  const [showPaydayModal, setShowPaydayModal] = useState(false);
  
  // Interaction State
  const [actualPayAmount, setActualPayAmount] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paydayConfirmationText, setPaydayConfirmationText] = useState('');

  // --- Derived State (Logic) ---

  const unpaidBills = useMemo(() => bills.filter(b => b.status !== 'paid'), [bills]);

  /**
   * Sorts bills by urgency score:
   * 0: Overdue (Highest)
   * 1: Due Today
   * 2: Upcoming
   */
  const sortedBills = useMemo(() => {
    return [...unpaidBills].sort((a, b) => {
      const getScore = (bill: Bill) => {
        if (bill.status === 'overdue') return 0;
        if (bill.status === 'due_today') return 1;
        return 2;
      };
      
      const scoreA = getScore(a);
      const scoreB = getScore(b);
      
      if (scoreA !== scoreB) return scoreA - scoreB;
      
      // Secondary sort: Paycheck Cycle
      if (a.paycheckLabel !== b.paycheckLabel) return a.paycheckLabel === 'Oct #2' ? -1 : 1;
      
      // Tertiary sort: Due Date
      const timeA = new Date(a.dueDate).getTime();
      const timeB = new Date(b.dueDate).getTime();
      if (timeA !== timeB) return timeA - timeB;
      
      // Quaternary sort: Amount (High to Low)
      return b.amount - a.amount;
    });
  }, [unpaidBills]);

  // Group bills by paycheck label for easier rendering
  const billsByPaycheck = useMemo(() => {
    const groups: { label: string; bills: Bill[] }[] = [];
    sortedBills.forEach((bill) => {
      let group = groups.find((g) => g.label === bill.paycheckLabel);
      if (!group) {
        group = { label: bill.paycheckLabel, bills: [] };
        groups.push(group);
      }
      group.bills.push(bill);
    });
    return groups;
  }, [sortedBills]);

  const totalUnpaid = unpaidBills.reduce((acc, bill) => acc + bill.amount, 0);
  
  const currentCycleBills = useMemo(() => bills.filter(b => b.paycheckLabel === currentCycleLabel), [bills]);
  const totalCycleAmount = currentCycleBills.reduce((acc, b) => acc + b.amount, 0);
  const paidCycleAmount = currentCycleBills.filter(b => b.status === 'paid').reduce((acc, b) => acc + b.amount, 0);
  const percentPaid = totalCycleAmount > 0 ? (paidCycleAmount / totalCycleAmount) * 100 : 0;
  const remainingBillCount = currentCycleBills.filter(b => b.status !== 'paid').length;

  const billToPay = bills.find(b => b.id === confirmingBillId);
  const detailsBill = bills.find(b => b.id === viewingDetailsBillId);
  const discussingBill = bills.find(b => b.id === discussingBillId);
  
  // Calculate difference between expected and actual paid amount
  const diffData = useMemo(() => {
      if (!billToPay || !actualPayAmount) return null;
      const expected = billToPay.amount;
      const actual = parseFloat(actualPayAmount);
      if (isNaN(actual)) return null;
      const diff = actual - expected;
      const percent = expected !== 0 ? (diff / expected) * 100 : 0;
      return { diff, percent };
  }, [billToPay, actualPayAmount]);

  // --- Handlers ---

  const handlePayClick = (e: React.MouseEvent, bill: Bill) => {
    e.stopPropagation();
    setConfirmingBillId(bill.id);
    setActualPayAmount(bill.amount.toFixed(2));
  };

  const confirmPayment = async () => {
    if (!confirmingBillId) return;
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API
    const paidAmount = parseFloat(actualPayAmount) || 0;
    
    setBills(prev => prev.map(b => b.id === confirmingBillId ? { ...b, status: 'paid', amount: paidAmount } : b));
    setCurrentBalance(prev => prev - paidAmount);
    
    setIsProcessing(false);
    setConfirmingBillId(null);
    setActualPayAmount('');
  };

  const handleConfirmPayday = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API
    setCurrentBalance(prev => prev + 2250.00); // Simulate income
    setIsProcessing(false);
    setShowPaydayModal(false);
    setPaydayConfirmationText('');
  };

  const handleAddComment = (text: string) => {
    if (!discussingBillId) return;
    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      text,
      timestamp: 'Just now',
      isMe: true
    };
    setBills(prev => prev.map(b => b.id === discussingBillId ? { ...b, comments: [...(b.comments || []), newComment] } : b));
  };

  const getStatusColor = (status: Bill['status']) => {
    switch (status) {
      case 'overdue': return 'border-red-300 dark:border-red-900 bg-red-50/50 dark:bg-red-900/10 shadow-[0px_2px_8px_rgba(239,68,68,0.15)]';
      case 'due_today': return 'border-orange-300 dark:border-orange-900 bg-orange-50/50 dark:bg-orange-900/10 shadow-[0px_2px_8px_rgba(249,115,22,0.15)]';
      case 'due_soon': return 'border-amber-200 dark:border-amber-800';
      default: return 'border-transparent';
    }
  };

  const getStatusLabel = (bill: Bill) => {
    const due = new Date(bill.dueDate);
    switch (bill.status) {
        case 'overdue': return 'Overdue';
        case 'due_today': return 'Due Today';
        case 'due_soon': 
             const diff = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
             return `Due in ${diff} days`;
        default: return due.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col group/design-root text-slate-900 dark:text-white bg-background-light dark:bg-background-dark transition-colors duration-200">
      
      {/* --- Header --- */}
      <div className="flex flex-col md:flex-row md:items-center bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm p-4 pb-2 justify-between sticky top-0 z-20 border-b border-transparent transition-colors duration-200 md:p-6 md:pb-0 gap-4">
        <div className="flex items-center justify-between w-full">
          <div>
              <h1 className="text-slate-900 dark:text-white text-lg md:text-2xl font-bold leading-tight">Home</h1>
              <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Oct 26 • 5 Days to Payday</p>
          </div>
          <div className="flex items-center gap-2">
            <button 
                onClick={() => setShowPaydayModal(true)}
                className="neo-btn-primary px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95"
            >
                <span className="material-symbols-outlined text-lg sm:text-xl">attach_money</span>
                <span className="hidden sm:inline">I Got Paid</span>
            </button>
            <div className="md:hidden">
                <button className="neo-btn flex items-center justify-center rounded-full h-10 w-10 text-slate-900 dark:text-white">
                <span className="material-symbols-outlined text-xl">person</span>
                </button>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-1 p-4 pt-4 md:p-6 space-y-4">
        
        {/* Compact Progress Card */}
        <div className="neo-card p-4">
            <div className="flex justify-between items-center mb-2">
                <div className="flex items-baseline gap-2">
                    <p className="text-2xl font-bold text-slate-900 dark:text-white leading-none">{Math.round(percentPaid)}%</p>
                    <p className="text-xs font-bold text-slate-600 dark:text-slate-400">Paid for <span className="text-primary">{currentCycleLabel}</span></p>
                </div>
                <div className="text-right">
                        <p className="text-xs font-bold text-slate-900 dark:text-white">${paidCycleAmount.toLocaleString()} <span className="text-slate-400 font-normal">/ ${totalCycleAmount.toLocaleString()}</span></p>
                </div>
            </div>
            <div className="neo-inset h-3 w-full rounded-full overflow-hidden mb-3 p-[1px] bg-slate-200 dark:bg-black/40 shadow-inner">
                <div className={clsx("h-full rounded-full transition-all duration-1000 ease-out shadow-[2px_0_5px_rgba(0,0,0,0.2)]", percentPaid === 100 ? "bg-gradient-to-r from-emerald-500 to-emerald-400" : "bg-gradient-to-r from-primary to-green-400")} style={{ width: `${percentPaid}%` }}></div>
            </div>
            <div className={clsx("rounded-lg p-2 flex items-center gap-2 border shadow-sm", percentPaid === 100 ? "bg-emerald-50 dark:bg-emerald-900/10 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300" : "bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300")}>
                <span className="material-symbols-outlined text-lg">{percentPaid === 100 ? 'verified' : 'info'}</span>
                <div>
                    <p className="font-bold text-xs leading-tight">{percentPaid === 100 ? "All set! Free to spend." : `${remainingBillCount} bills remaining to safe spend.`}</p>
                </div>
            </div>
        </div>

        {/* --- Priority To-Pay --- */}
        <div className="flex flex-col gap-3">
             <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 uppercase tracking-wider">
                    <span className="material-symbols-outlined text-primary text-lg">playlist_play</span>
                    Priority To-Pay
                </h3>
             </div>

             <div className="flex flex-col gap-3">
                {sortedBills.length === 0 ? (
                    <div className="neo-inset flex flex-col items-center justify-center py-8 px-6 rounded-xl border border-dashed border-gray-300 dark:border-gray-700">
                        <span className="material-symbols-outlined text-4xl text-green-500 mb-2">check_circle</span>
                        <h3 className="text-slate-900 dark:text-white font-bold text-sm">All caught up!</h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400 text-center max-w-[200px]">No pending bills found. Enjoy your financial freedom.</p>
                        <button onClick={() => navigate('/planning')} className="mt-3 text-primary text-xs font-bold hover:underline">View All Bills</button>
                    </div>
                ) : (
                    billsByPaycheck.map((group) => (
                        <div key={group.label} className={clsx("flex flex-col gap-2", group.label !== currentCycleLabel ? "opacity-75 grayscale-[0.2]" : "")}>
                             {group.label !== currentCycleLabel && (
                                <div className="flex items-center gap-2 mt-1 px-1">
                                    <h4 className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{group.label}</h4>
                                    <div className="h-px bg-slate-200 dark:bg-slate-700 flex-1"></div>
                                </div>
                             )}

                            {group.bills.map((bill) => (
                                <div key={bill.id} 
                                    onClick={() => setViewingDetailsBillId(bill.id)}
                                    className={clsx(
                                    "neo-card group flex items-center gap-3 p-3 transition-all duration-200 cursor-pointer hover:shadow-lg",
                                    getStatusColor(bill.status)
                                )}>
                                    {/* Icon */}
                                    <div className="neo-btn flex items-center justify-center rounded-full size-12 shrink-0 text-slate-700 dark:text-slate-300 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800">
                                        <span className="material-symbols-outlined text-xl">{bill.icon}</span>
                                    </div>
                                    
                                    {/* Info */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-1.5">
                                            <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate leading-tight">{bill.name}</h4>
                                            {(bill.status === 'overdue' || bill.status === 'due_today') && (
                                                <span className="flex size-1.5 rounded-full bg-red-600 animate-pulse shrink-0 shadow-[0_0_5px_red]"></span>
                                            )}
                                        </div>
                                        <div className="flex flex-col">
                                            <div className="flex items-center gap-1.5 text-[11px] font-medium opacity-80 truncate leading-tight mt-0.5 text-slate-600 dark:text-slate-400">
                                                <span>{bill.category}</span>
                                                <span className="opacity-50">•</span>
                                                <span>{getStatusLabel(bill)}</span>
                                            </div>
                                            {(bill.status === 'overdue' || bill.status === 'due_soon' || bill.status === 'due_today') && (
                                                <div className="origin-left scale-95 -ml-0.5 mt-0.5">
                                                    <CountdownTimer targetDate={new Date(bill.dueDate)} status={bill.status} />
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {/* Actions */}
                                    <div className="flex items-center gap-2 shrink-0">
                                        <div className="flex items-center gap-1">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); setDiscussingBillId(bill.id); }}
                                                className="neo-btn rounded-full size-8 flex items-center justify-center text-slate-500 hover:text-primary transition-colors active:scale-95"
                                            >
                                                <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                                            </button>
                                            
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); setViewingDetailsBillId(bill.id); }}
                                                className="neo-btn rounded-full size-8 flex items-center justify-center text-slate-500 hover:text-primary transition-colors active:scale-95"
                                            >
                                                <span className="material-symbols-outlined text-base">visibility</span>
                                            </button>
                                        </div>

                                        <div className="text-right px-1">
                                            <p className="font-bold text-sm text-slate-900 dark:text-white tabular-nums drop-shadow-sm">
                                                ${bill.amount.toFixed(0)}
                                            </p>
                                        </div>
                                        <button 
                                            onClick={(e) => handlePayClick(e, bill)}
                                            className={clsx(
                                                "h-9 px-4 rounded-lg font-bold text-xs shadow-sm transition-all active:scale-95 flex items-center justify-center border",
                                                bill.status === 'overdue' 
                                                    ? "bg-red-600 text-white border-red-500 hover:bg-red-700 shadow-[0_2px_5px_rgba(220,38,38,0.4)]" 
                                                    : "neo-btn-primary"
                                            )}
                                        >
                                            Pay
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ))
                )}
             </div>
        </div>

      </main>

      {/* --- Single Bill Modal (Shared Details) --- */}
      {detailsBill && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
              <div className="neo-card w-full max-w-sm overflow-hidden p-6 animate-slide-up sm:animate-none max-h-[90vh] overflow-y-auto no-scrollbar">
                  <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                          <div className="neo-inset flex items-center justify-center rounded-full size-12 bg-primary/10 text-primary border border-primary/20">
                              <span className="material-symbols-outlined text-2xl">{detailsBill.icon}</span>
                          </div>
                          <div>
                             <h3 className="font-bold text-slate-900 dark:text-white text-lg">{detailsBill.name}</h3>
                             <p className="text-xs text-slate-500 font-bold uppercase">{detailsBill.status === 'paid' ? 'PAID' : 'DUE'}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-2">
                          <button onClick={() => { setDiscussingBillId(detailsBill.id); }} className="neo-btn rounded-full p-2 text-gray-500 hover:text-primary transition-colors">
                              <span className="material-symbols-outlined text-lg">chat_bubble_outline</span>
                          </button>
                          <button onClick={() => setViewingDetailsBillId(null)} className="neo-btn rounded-full p-2">
                              <span className="material-symbols-outlined text-xl">close</span>
                          </button>
                      </div>
                  </div>
                  
                  <div className="flex flex-col items-center justify-center py-4 mb-6 border-b border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-black/20 rounded-xl neo-inset">
                        <p className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">${detailsBill.amount.toFixed(2)}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">{detailsBill.companyName || 'Bill'}</p>
                  </div>

                  <div className="space-y-5">
                      {/* Core Info Grid */}
                      <div className="grid grid-cols-2 gap-3">
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Due Date</span>
                              <span className="font-bold text-slate-800 dark:text-white text-sm mt-1">{new Date(detailsBill.dueDate).toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}</span>
                          </div>
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Paycheck</span>
                              <span className="font-bold text-slate-800 dark:text-white text-sm mt-1">{detailsBill.paycheckLabel}</span>
                          </div>
                      </div>

                      {detailsBill.website && (
                          <a href={detailsBill.website} target="_blank" rel="noopener noreferrer" className="neo-btn-primary flex items-center justify-center gap-2 w-full py-3 rounded-xl font-bold text-sm">
                              <span>Go to Payment Site</span>
                              <span className="material-symbols-outlined text-lg">open_in_new</span>
                          </a>
                      )}
                      
                      {/* Shared Creds */}
                      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl space-y-3 border border-gray-200 dark:border-gray-700 shadow-inner">
                          <div className="flex items-center gap-2 mb-2">
                              <span className="material-symbols-outlined text-slate-400 text-lg">lock</span>
                              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Shared Details</span>
                          </div>
                          
                          {detailsBill.accountNumber && (
                              <div className="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-2">
                                  <p className="text-xs font-medium text-slate-500">Account #</p>
                                  <p className="font-mono font-bold text-slate-900 dark:text-white select-all">{detailsBill.accountNumber}</p>
                              </div>
                          )}
                          
                          {(detailsBill.username || detailsBill.password) && (
                              <div className="grid grid-cols-2 gap-4 pt-1">
                                  {detailsBill.username && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Username</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.username}</p>
                                      </div>
                                  )}
                                  {detailsBill.password && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Password</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.password}</p>
                                      </div>
                                  )}
                              </div>
                          )}
                          
                          {!detailsBill.accountNumber && !detailsBill.username && !detailsBill.password && (
                              <p className="text-xs text-slate-400 italic">No credentials shared.</p>
                          )}
                      </div>

                      {detailsBill.notes && (
                          <div className="bg-yellow-50 dark:bg-yellow-900/10 p-3 rounded-xl border border-yellow-100 dark:border-yellow-900/30">
                              <p className="text-xs font-bold text-yellow-600 dark:text-yellow-500 uppercase tracking-wider mb-1">Shared Notes</p>
                              <p className="text-sm text-slate-700 dark:text-slate-300 italic">"{detailsBill.notes}"</p>
                          </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-3 pt-2">
                          <button 
                              onClick={() => navigate('/planning')}
                              className="neo-btn flex-1 py-3 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shadow-sm"
                          >
                              Edit
                          </button>
                          {detailsBill.status !== 'paid' && (
                              <button 
                                  onClick={(e) => {
                                      setViewingDetailsBillId(null);
                                      handlePayClick(e, detailsBill);
                                  }}
                                  className="neo-btn-primary flex-1 py-3 rounded-xl font-bold shadow-lg"
                              >
                                  Pay Bill
                              </button>
                          )}
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Confirm Pay Modal */}
      {billToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="neo-card w-full max-w-sm overflow-hidden transform transition-all scale-100 p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className={clsx("neo-inset flex items-center justify-center rounded-full size-12", "text-primary bg-primary/10")}>
                  <span className={clsx("material-symbols-outlined text-2xl")}>{billToPay.icon}</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">{billToPay.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Confirm Payment</p>
                </div>
              </div>
              
              <div className="mb-6 space-y-4">
                  <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Expected Amount</label>
                      <p className="text-xl font-bold text-slate-900 dark:text-white">${billToPay.amount.toFixed(2)}</p>
                  </div>
                  
                  <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Actual Amount Paid</label>
                      <input 
                        type="number"
                        step="0.01"
                        value={actualPayAmount}
                        onChange={(e) => setActualPayAmount(e.target.value)}
                        className="neo-inset w-full p-3 text-lg font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                  </div>

                  {diffData && diffData.diff !== 0 && (
                      <div className={clsx(
                          "flex items-center gap-2 text-sm font-bold p-3 rounded-lg animate-fade-in",
                          diffData.diff > 0 ? "bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400" : "bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400"
                      )}>
                          <span className="material-symbols-outlined text-lg">
                              {diffData.diff > 0 ? 'trending_up' : 'trending_down'}
                          </span>
                          <span>
                              {diffData.diff > 0 ? '+' : ''}{diffData.diff.toFixed(2)} ({diffData.diff > 0 ? '+' : ''}{diffData.percent.toFixed(1)}%)
                          </span>
                      </div>
                  )}
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => !isProcessing && setConfirmingBillId(null)}
                  disabled={isProcessing}
                  className="neo-btn flex-1 px-4 py-3 rounded-xl text-slate-700 dark:text-slate-300 font-bold disabled:opacity-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmPayment}
                  disabled={isProcessing || !actualPayAmount}
                  className="neo-btn-primary flex-1 px-4 py-3 rounded-xl font-bold disabled:opacity-50 flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  {isProcessing ? (
                    <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                  ) : (
                    'Confirm'
                  )}
                </button>
              </div>
          </div>
        </div>
      )}

      {/* Payday Modal */}
      {showPaydayModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
              <div className="neo-card w-full max-w-md overflow-hidden transform transition-all scale-100 p-0 border-2 border-slate-200 dark:border-slate-700">
                  <div className="bg-emerald-500 p-8 text-white text-center relative overflow-hidden">
                       <span className="material-symbols-outlined text-9xl absolute -bottom-8 -right-8 opacity-20 rotate-12">payments</span>
                       <h2 className="text-3xl font-bold relative z-10 text-shadow-sm">Payday Routine</h2>
                       <p className="text-emerald-50 font-medium relative z-10 mt-1">Clear the board and relax.</p>
                  </div>
                  
                  <div className="p-8">
                      <div className="mb-6">
                          <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                             Type "i got paid" to confirm
                          </label>
                          <input 
                            type="text" 
                            className="neo-inset w-full p-4 text-center font-bold text-lg text-gray-900 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none"
                            placeholder="i got paid"
                            value={paydayConfirmationText}
                            onChange={(e) => setPaydayConfirmationText(e.target.value)}
                          />
                      </div>
                      <div className="space-y-4">
                          <button onClick={handleConfirmPayday} disabled={paydayConfirmationText.toLowerCase() !== 'i got paid' || isProcessing} className="neo-btn-primary w-full h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]">
                              {isProcessing ? (
                                <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                              ) : (
                                <>
                                    <span className="material-symbols-outlined">check_circle</span>
                                    <span>Confirm Receipt</span>
                                </>
                              )}
                          </button>
                      </div>
                      <div className="mt-4 text-center">
                          <button onClick={() => setShowPaydayModal(false)} disabled={isProcessing} className="text-slate-500 dark:text-slate-400 font-bold text-sm hover:underline">Cancel</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Comment Modal */}
      <CommentModal 
        isOpen={!!discussingBill}
        onClose={() => setDiscussingBillId(null)}
        title={discussingBill?.name || 'Bill'}
        comments={discussingBill?.comments || []}
        onAddComment={handleAddComment}
      />
    </div>
  );
}