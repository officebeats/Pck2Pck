import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';

interface NotificationItem {
  id: number;
  type: 'bill' | 'warning' | 'income' | 'chat' | 'goal';
  title: string;
  description: string;
  time: string;
  dateLabel: 'Today' | 'Yesterday' | 'This Week' | 'Earlier';
  icon: string;
  iconBg: string;
  iconColor: string;
  link?: string;
  read: boolean;
  archived: boolean;
}

const MOCK_NOTIFICATIONS: NotificationItem[] = [
    {
      id: 1,
      type: 'bill',
      title: 'Bill Due Soon',
      description: 'Netflix - $15.99 due in 2 days',
      time: '1h ago',
      dateLabel: 'Today',
      icon: 'receipt_long',
      iconBg: 'bg-primary/20',
      iconColor: 'text-primary',
      link: '/bill-discussion',
      read: false,
      archived: false
    },
    {
      id: 2,
      type: 'warning',
      title: 'Budget Warning',
      description: "You've spent 90% of your 'Groceries' budget",
      time: '3h ago',
      dateLabel: 'Today',
      icon: 'warning',
      iconBg: 'bg-red-500/20',
      iconColor: 'text-red-500',
      read: false,
      archived: false
    },
    {
      id: 3,
      type: 'income',
      title: 'Income Received',
      description: 'Your paycheck of $1,250 has been deposited',
      time: 'Yesterday',
      dateLabel: 'Yesterday',
      icon: 'account_balance_wallet',
      iconBg: 'bg-green-500/20',
      iconColor: 'text-green-500',
      read: true,
      archived: false
    },
    {
      id: 4,
      type: 'chat',
      title: 'New Message',
      description: "Jessica in 'Family Chat'",
      time: 'Yesterday',
      dateLabel: 'Yesterday',
      icon: 'chat',
      iconBg: 'bg-slate-500/20',
      iconColor: 'text-slate-500',
      link: '/chat',
      read: true,
      archived: false
    },
    {
      id: 5,
      type: 'goal',
      title: 'Savings Goal Update',
      description: "You're 75% of the way to your 'Vacation' goal!",
      time: '2 days ago',
      dateLabel: 'This Week',
      icon: 'trending_up',
      iconBg: 'bg-purple-500/20',
      iconColor: 'text-purple-500',
      read: true,
      archived: true
    }
];

export default function Notifications() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'inbox' | 'archived'>('inbox');

  // State with Persistence
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
      const saved = localStorage.getItem('pchk_notifications');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch(e) {
              console.error(e);
          }
      }
      return MOCK_NOTIFICATIONS;
  });

  useEffect(() => {
      localStorage.setItem('pchk_notifications', JSON.stringify(notifications));
  }, [notifications]);

  const handleArchive = (e: React.MouseEvent, id: number) => {
      e.stopPropagation();
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, archived: true } : n));
  };

  const handleUnarchive = (e: React.MouseEvent, id: number) => {
      e.stopPropagation();
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, archived: false } : n));
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
      e.stopPropagation();
      setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const filteredNotifications = notifications.filter(n => activeTab === 'inbox' ? !n.archived : n.archived);

  // Group by date label
  const groupedNotifications = filteredNotifications.reduce((acc, note) => {
    if (!acc[note.dateLabel]) acc[note.dateLabel] = [];
    acc[note.dateLabel].push(note);
    return acc;
  }, {} as Record<string, NotificationItem[]>);

  const labels: ('Today' | 'Yesterday' | 'This Week' | 'Earlier')[] = ['Today', 'Yesterday', 'This Week', 'Earlier'];

  return (
    <div className="relative flex h-screen min-h-screen w-full flex-col bg-background-light dark:bg-background-dark group/design-root overflow-x-hidden font-sans transition-colors duration-200">
      {/* Top App Bar */}
      <header className="flex shrink-0 items-center justify-between bg-background-light dark:bg-background-dark p-3 pb-2 sticky top-0 z-10 border-b border-slate-200 dark:border-gray-700 transition-colors">
        <div className="flex h-10 w-10 shrink-0 items-center">
           <button onClick={() => navigate(-1)} className="text-slate-800 dark:text-white flex size-9 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
           </button>
        </div>
        <h1 className="text-lg font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white flex-1 text-center">Alerts</h1>
        <div className="flex w-10 items-center justify-end">
          <button className="flex h-10 cursor-pointer items-center justify-center overflow-hidden rounded-lg bg-transparent text-primary gap-2 text-base font-bold leading-normal tracking-[0.015em] min-w-0 p-0 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full w-10 transition-colors">
            <span className="material-symbols-outlined text-xl">settings</span>
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="px-4 py-2">
          <div className="neo-inset flex p-1">
              <button 
                onClick={() => setActiveTab('inbox')}
                className={clsx(
                    "flex-1 py-1.5 rounded-lg text-xs font-bold transition-all",
                    activeTab === 'inbox' 
                        ? "bg-white dark:bg-card-dark text-slate-900 dark:text-white shadow-sm" 
                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                )}
              >
                  Inbox
              </button>
              <button 
                onClick={() => setActiveTab('archived')}
                className={clsx(
                    "flex-1 py-1.5 rounded-lg text-xs font-bold transition-all",
                    activeTab === 'archived' 
                        ? "bg-white dark:bg-card-dark text-slate-900 dark:text-white shadow-sm" 
                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                )}
              >
                  Archived
              </button>
          </div>
      </div>

      {/* Notification List */}
      <main className="flex-1 overflow-y-auto">
        <div className="flex flex-col gap-1 px-4 py-3">
          
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 px-6 text-center animate-fade-in">
                <div className="w-20 h-20 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-6">
                  <span className="material-symbols-outlined text-4xl text-slate-400">
                      {activeTab === 'inbox' ? 'notifications_off' : 'inventory_2'}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                    {activeTab === 'inbox' ? 'All caught up!' : 'No archived alerts'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs">
                  {activeTab === 'inbox' ? 'No new notifications at the moment.' : 'Archived notifications will appear here.'}
                </p>
            </div>
          ) : (
            labels.map(label => {
              const group = groupedNotifications[label];
              if (!group || group.length === 0) return null;

              return (
                <div key={label} className="animate-fade-in">
                  <div className="px-1 py-1 pt-3 first:pt-0">
                    <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">{label}</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    {group.map(note => (
                       <div 
                         key={note.id} 
                         onClick={() => note.link && navigate(note.link)}
                         className={`group relative flex items-center gap-3 bg-white dark:bg-card-dark p-3 rounded-xl justify-between shadow-sm transition-colors duration-200 border border-transparent ${note.link ? 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800' : ''}`}
                       >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className={`flex size-10 shrink-0 items-center justify-center rounded-full ${note.iconBg} ${note.iconColor}`}>
                            <span className="material-symbols-outlined text-xl">{note.icon}</span>
                          </div>
                          <div className="flex flex-col justify-center min-w-0">
                            <p className="text-sm font-bold leading-normal text-slate-900 dark:text-white line-clamp-1">{note.title}</p>
                            <p className="text-xs font-medium leading-normal text-slate-500 dark:text-slate-400 line-clamp-2">{note.description}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1.5 self-start shrink-0">
                          <p className="text-[10px] font-medium leading-normal text-slate-400 dark:text-slate-500">{note.time}</p>
                          {!note.read && activeTab === 'inbox' && <div className="size-2 rounded-full bg-primary"></div>}
                        </div>

                        {/* Hover Actions */}
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-1 bg-white dark:bg-card-dark shadow-sm rounded-lg p-1 border border-gray-100 dark:border-gray-700 animate-fade-in">
                            {activeTab === 'inbox' ? (
                                <button 
                                    onClick={(e) => handleArchive(e, note.id)} 
                                    className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300" 
                                    title="Archive"
                                >
                                    <span className="material-symbols-outlined text-lg">archive</span>
                                </button>
                            ) : (
                                <>
                                    <button 
                                        onClick={(e) => handleUnarchive(e, note.id)} 
                                        className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300" 
                                        title="Unarchive"
                                    >
                                        <span className="material-symbols-outlined text-lg">unarchive</span>
                                    </button>
                                    <button 
                                        onClick={(e) => handleDelete(e, note.id)} 
                                        className="p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500" 
                                        title="Delete"
                                    >
                                        <span className="material-symbols-outlined text-lg">delete</span>
                                    </button>
                                </>
                            )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })
          )}

        </div>
      </main>
    </div>
  );
}