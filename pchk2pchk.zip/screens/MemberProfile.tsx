import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import clsx from 'clsx';
import CommentModal, { Comment } from '../components/CommentModal';

interface AssignedBill {
    id: number;
    name: string;
    amount: number;
    dueDate: string;
    status: 'overdue' | 'due_soon' | 'paid' | 'upcoming';
    icon: string;
    comments?: Comment[];
    // Shared Details Mock
    companyName?: string;
    website?: string;
    username?: string;
    password?: string;
    accountNumber?: string;
    notes?: string;
}

interface ActivityItem {
    id: number;
    action: string;
    target: string;
    time: string;
    icon: string;
}

export default function MemberProfile() {
  const navigate = useNavigate();
  const { id } = useParams();

  // Mock data simulation based on ID
  const isUrgentUser = id === '1';

  const member = {
    name: isUrgentUser ? 'Sarah' : (id === '0' ? 'You' : 'Maya'),
    role: id === '0' ? 'Family Admin' : 'Member',
    avatar: id === '0' 
        ? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=faces' 
        : (id === '1' ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=faces' 
        : 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=faces'),
    totalCommitment: 850.00,
    paidThisCycle: 400.00,
  };

  const [assignedBills, setAssignedBills] = useState<AssignedBill[]>(
    isUrgentUser ? [
      { id: 1, name: 'Internet Bill', amount: 89.99, dueDate: 'Yesterday', status: 'overdue', icon: 'wifi', comments: [] },
      { id: 2, name: 'Phone Plan', amount: 45.00, dueDate: 'Today', status: 'due_soon', icon: 'phone_iphone', comments: [] },
      { id: 3, name: 'Netflix', amount: 15.99, dueDate: 'Oct 28', status: 'upcoming', icon: 'tv_gen', comments: [] },
    ] : [
      { id: 4, name: 'Gym Membership', amount: 35.00, dueDate: 'Oct 30', status: 'upcoming', icon: 'fitness_center', comments: [] },
      { id: 5, name: 'Spotify', amount: 10.00, dueDate: 'Paid Oct 15', status: 'paid', icon: 'music_note', comments: [] },
    ]
  );

  const [availableBills, setAvailableBills] = useState<AssignedBill[]>([
    { id: 101, name: 'Water Bill', amount: 45.50, dueDate: 'Nov 5', status: 'upcoming', icon: 'water_drop', comments: [] },
    { id: 102, name: 'Trash Collection', amount: 25.00, dueDate: 'Nov 2', status: 'upcoming', icon: 'delete', comments: [] },
    { id: 103, name: 'Car Insurance', amount: 120.00, dueDate: 'Nov 10', status: 'upcoming', icon: 'security', comments: [] },
  ]);

  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'urgent' | 'upcoming' | 'paid'>('all');
  const [discussingBillId, setDiscussingBillId] = useState<number | null>(null);
  const [viewingDetailsBillId, setViewingDetailsBillId] = useState<number | null>(null);

  const pendingAmount = member.totalCommitment - member.paidThisCycle;
  const progressPercent = (member.paidThisCycle / member.totalCommitment) * 100;

  const recentActivity: ActivityItem[] = isUrgentUser ? [
    { id: 1, action: 'Commented on', target: 'Internet Bill', time: '2 hours ago', icon: 'chat_bubble' },
    { id: 2, action: 'Paid', target: 'Electric Bill', time: 'Yesterday', icon: 'check_circle' },
  ] : [
    { id: 3, action: 'Paid', target: 'Spotify', time: '3 days ago', icon: 'check_circle' },
  ];

  const urgentBills = assignedBills.filter(b => b.status === 'overdue' || b.status === 'due_soon');

  const handleAssignBill = (bill: AssignedBill) => {
    setAssignedBills([...assignedBills, bill]);
    setAvailableBills(availableBills.filter(b => b.id !== bill.id));
    setIsAssignModalOpen(false);
  };

  const handleAddComment = (text: string) => {
    if (!discussingBillId) return;
    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      text,
      timestamp: 'Just now',
      isMe: true
    };
    setAssignedBills(prev => prev.map(b => b.id === discussingBillId ? { ...b, comments: [...(b.comments || []), newComment] } : b));
  };

  const filteredBills = assignedBills.filter(bill => {
      if (filter === 'all') return true;
      if (filter === 'paid') return bill.status === 'paid';
      if (filter === 'urgent') return bill.status === 'overdue' || bill.status === 'due_soon';
      if (filter === 'upcoming') return bill.status === 'upcoming';
      return true;
  });

  const discussingBill = assignedBills.find(b => b.id === discussingBillId);
  const detailsBill = assignedBills.find(b => b.id === viewingDetailsBillId);

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-sans transition-colors duration-200">
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center bg-background-light/90 dark:bg-background-dark/90 p-3 pb-2 justify-between backdrop-blur-sm transition-colors border-b border-gray-200 dark:border-gray-700">
        <button onClick={() => navigate(-1)} className="text-slate-800 dark:text-white flex size-9 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-slate-900 dark:text-white flex-1 text-center">Member Profile</h1>
        <div className="size-9"></div>
      </div>

      <main className="flex-1 p-4 md:p-6 pb-24 space-y-4">
        {/* Profile Hero - Compact */}
        <div className="flex items-center gap-4 bg-white dark:bg-card-dark p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="relative shrink-0">
                <img src={member.avatar} alt={member.name} className="size-16 rounded-full object-cover border-2 border-white dark:border-slate-700 shadow-md" />
                {urgentBills.length > 0 && (
                    <div className="absolute -bottom-1 -right-1 bg-red-500 text-white p-1 rounded-full border-2 border-white dark:border-background-dark animate-pulse">
                        <span className="material-symbols-outlined text-[10px] font-bold block">priority_high</span>
                    </div>
                )}
            </div>
            <div>
                 <h2 className="text-lg font-bold text-slate-900 dark:text-white">{member.name}</h2>
                 <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{member.role}</p>
            </div>
        </div>

        {/* Urgency Bubble / Alert Section */}
        {urgentBills.length > 0 && (
            <div className="bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-xl p-3 animate-fade-in">
                <div className="flex items-start gap-3">
                    <div className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 p-1.5 rounded-full shrink-0">
                        <span className="material-symbols-outlined text-lg">notification_important</span>
                    </div>
                    <div>
                        <h3 className="font-bold text-red-700 dark:text-red-400 text-sm">Action Required</h3>
                        <p className="text-xs text-red-600/80 dark:text-red-300/80 mt-0.5">
                            {member.name} has {urgentBills.length} bills pending.
                        </p>
                    </div>
                </div>
            </div>
        )}

        {/* Financial Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
            <div className="bg-white dark:bg-card-dark p-3 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">Total Commitment</p>
                <p className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">${member.totalCommitment.toFixed(0)}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Per Paycheck</p>
            </div>
            <div className="bg-white dark:bg-card-dark p-3 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">Remaining</p>
                <p className={clsx("text-lg font-bold mt-0.5", pendingAmount > 0 ? "text-orange-600" : "text-green-600")}>
                    ${pendingAmount.toFixed(0)}
                </p>
                <div className="w-full bg-gray-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div className="bg-primary h-full rounded-full transition-all duration-500" style={{width: `${progressPercent}%`}}></div>
                </div>
            </div>
        </div>

        {/* Current Paycheck Assignments */}
        <div>
            <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">Assigned Bills (This Cycle)</h3>
                <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">{assignedBills.length}</span>
                    <button 
                        onClick={() => setIsAssignModalOpen(true)}
                        className="flex items-center justify-center size-7 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                    >
                        <span className="material-symbols-outlined text-base">add</span>
                    </button>
                </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex gap-2 mb-3 overflow-x-auto no-scrollbar pb-1">
                {(['all', 'urgent', 'upcoming', 'paid'] as const).map((f) => (
                    <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={clsx(
                            "px-3 py-1 rounded-full text-[10px] font-bold capitalize whitespace-nowrap transition-all border",
                            filter === f 
                                ? "bg-slate-800 text-white border-slate-900 dark:bg-white dark:text-slate-900 dark:border-white shadow-sm" 
                                : "bg-white text-slate-600 border-gray-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700"
                        )}
                    >
                        {f}
                    </button>
                ))}
            </div>
            
            <div className="flex flex-col gap-2">
                {filteredBills.map(bill => (
                    <div 
                        key={bill.id} 
                        onClick={() => setViewingDetailsBillId(bill.id)}
                        className={clsx(
                        "flex items-center gap-3 p-3 rounded-xl border transition-colors animate-fade-in cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800",
                        bill.status === 'overdue' 
                            ? "bg-white dark:bg-card-dark border-red-200 dark:border-red-900/50 shadow-sm" 
                            : bill.status === 'due_soon'
                                ? "bg-white dark:bg-card-dark border-orange-200 dark:border-orange-900/50 shadow-sm"
                                : "bg-white dark:bg-card-dark border-transparent shadow-sm"
                    )}>
                        <div className={clsx(
                            "flex items-center justify-center size-9 rounded-full shrink-0",
                            bill.status === 'overdue' ? "bg-red-100 text-red-600" : 
                            bill.status === 'due_soon' ? "bg-orange-100 text-orange-600" :
                            bill.status === 'paid' ? "bg-green-100 text-green-600" : "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300"
                        )}>
                            <span className="material-symbols-outlined text-lg">{bill.icon}</span>
                        </div>
                        <div className="flex-1">
                            <p className="font-bold text-slate-900 dark:text-white text-sm">{bill.name}</p>
                            <p className={clsx("text-[10px] font-medium", 
                                bill.status === 'overdue' ? "text-red-500" : 
                                bill.status === 'due_soon' ? "text-orange-500" : "text-slate-500"
                            )}>
                                {bill.status === 'overdue' ? `Overdue: ${bill.dueDate}` : 
                                 bill.status === 'due_soon' ? `Due: ${bill.dueDate}` : 
                                 bill.status === 'paid' ? 'Paid' : `Due: ${bill.dueDate}`}
                            </p>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                            <p className="font-bold text-slate-900 dark:text-white text-sm">${bill.amount.toFixed(0)}</p>
                            <button 
                                onClick={(e) => { e.stopPropagation(); setDiscussingBillId(bill.id); }}
                                className="text-slate-400 hover:text-primary transition-colors flex items-center gap-1"
                            >
                                <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                            </button>
                        </div>
                    </div>
                ))}
                
                {filteredBills.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-6 text-center bg-gray-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                        {assignedBills.length === 0 ? (
                            <>
                                <p className="text-xs text-gray-500 font-medium">No bills assigned for this cycle.</p>
                                <button 
                                    onClick={() => setIsAssignModalOpen(true)}
                                    className="text-primary text-xs font-bold mt-1.5 hover:underline"
                                >
                                    Assign a bill
                                </button>
                            </>
                        ) : (
                             <p className="text-xs text-gray-500">No {filter} bills found.</p>
                        )}
                    </div>
                )}
            </div>
        </div>

        {/* Recent Activity */}
        <div>
            <h3 className="font-bold text-slate-900 dark:text-white mb-2 text-sm">Recent Activity</h3>
            <div className="bg-white dark:bg-card-dark rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                {recentActivity.map((item, index) => (
                    <div key={item.id} className={clsx(
                        "flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors",
                        index !== recentActivity.length - 1 && "border-b border-gray-100 dark:border-gray-700"
                    )}>
                        <span className="material-symbols-outlined text-slate-400 text-base">{item.icon}</span>
                        <p className="text-xs text-slate-700 dark:text-slate-300 flex-1">
                            <span className="font-bold">{item.action}</span> {item.target}
                        </p>
                        <span className="text-[10px] text-slate-400 font-medium">{item.time}</span>
                    </div>
                ))}
            </div>
        </div>

      </main>

      {/* Floating Action / Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-3 bg-white dark:bg-card-dark border-t border-gray-200 dark:border-gray-700 md:pl-64">
        <div className="max-w-7xl mx-auto flex gap-3">
             <button 
                onClick={() => navigate('/chat')}
                className="flex-1 h-11 flex items-center justify-center gap-2 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 active:scale-95 text-sm"
            >
                <span className="material-symbols-outlined text-lg">forum</span>
                Message {member.name}
            </button>
        </div>
      </div>

      {/* Assign Bill Modal */}
      {isAssignModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center bg-black/50 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
          <div className="w-full max-w-sm rounded-t-2xl sm:rounded-2xl bg-white dark:bg-card-dark p-5 shadow-xl transform transition-transform animate-slide-up sm:animate-none">
            
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Assign Bill to {member.name}
              </h2>
              <button 
                onClick={() => setIsAssignModalOpen(false)}
                className="rounded-full p-1 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-gray-400"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[50vh] overflow-y-auto">
                {availableBills.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-8">
                        <span className="material-symbols-outlined text-4xl text-gray-300 mb-2">assignment_turned_in</span>
                        <p className="text-slate-500 text-xs">No unassigned bills available.</p>
                    </div>
                ) : (
                    availableBills.map(bill => (
                        <div 
                            key={bill.id} 
                            onClick={() => handleAssignBill(bill)}
                            className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-slate-800 cursor-pointer transition-colors active:scale-[0.99]"
                        >
                            <div className="flex items-center justify-center size-9 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                                <span className="material-symbols-outlined text-lg">{bill.icon}</span>
                            </div>
                            <div className="flex-1">
                                <p className="font-bold text-slate-900 dark:text-white text-sm">{bill.name}</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Due: {bill.dueDate}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <p className="font-bold text-slate-900 dark:text-white text-sm">${bill.amount.toFixed(0)}</p>
                                <span className="material-symbols-outlined text-primary text-xl">add_circle</span>
                            </div>
                        </div>
                    ))
                )}
            </div>
          </div>
        </div>
      )}

      {/* Shared Details / View Card Modal */}
      {detailsBill && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
              <div className="neo-card w-full max-w-sm overflow-hidden p-6 animate-slide-up sm:animate-none max-h-[90vh] overflow-y-auto no-scrollbar">
                  <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                          <div className={clsx("neo-inset flex items-center justify-center rounded-full size-12", "text-primary bg-primary/10")}>
                              <span className={clsx("material-symbols-outlined text-2xl")}>{detailsBill.icon}</span>
                          </div>
                          <div>
                             <h3 className="font-bold text-slate-900 dark:text-white text-lg">{detailsBill.name}</h3>
                             <p className="text-xs text-slate-500 font-bold uppercase">{detailsBill.status === 'paid' ? 'PAID' : 'DUE'}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-2">
                          <button onClick={() => { setDiscussingBillId(detailsBill.id); }} className="neo-btn rounded-full p-2 text-gray-500 hover:text-primary transition-colors">
                              <span className="material-symbols-outlined text-lg">chat_bubble_outline</span>
                          </button>
                          <button onClick={() => setViewingDetailsBillId(null)} className="neo-btn rounded-full p-2">
                              <span className="material-symbols-outlined text-xl">close</span>
                          </button>
                      </div>
                  </div>
                  
                  <div className="flex flex-col items-center justify-center py-2 mb-6 border-b border-gray-200 dark:border-gray-800">
                        <p className="text-3xl font-bold text-slate-900 dark:text-white">${detailsBill.amount.toFixed(2)}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{detailsBill.companyName || 'Bill'}</p>
                  </div>

                  <div className="space-y-5">
                      {/* Core Info Grid */}
                      <div className="grid grid-cols-2 gap-3">
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">Due Date</span>
                              <span className="font-bold text-slate-800 dark:text-white">{detailsBill.dueDate}</span>
                          </div>
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">Status</span>
                              <span className={clsx("font-bold capitalize", 
                                detailsBill.status === 'overdue' ? "text-red-500" : 
                                detailsBill.status === 'due_soon' ? "text-orange-500" : "text-slate-800 dark:text-white")}>
                                {detailsBill.status.replace('_', ' ')}
                              </span>
                          </div>
                      </div>
                      
                      {/* Shared Creds */}
                      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl space-y-3 border border-gray-100 dark:border-gray-700">
                          <div className="flex items-center gap-2 mb-2">
                              <span className="material-symbols-outlined text-slate-400 text-lg">lock</span>
                              <span className="text-xs font-bold text-slate-500 uppercase">Shared Details</span>
                          </div>
                          
                          {detailsBill.accountNumber && (
                              <div className="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-2">
                                  <p className="text-xs font-medium text-slate-500">Account #</p>
                                  <p className="font-mono font-bold text-slate-900 dark:text-white select-all">{detailsBill.accountNumber}</p>
                              </div>
                          )}
                          
                          {(detailsBill.username || detailsBill.password) && (
                              <div className="grid grid-cols-2 gap-4 pt-1">
                                  {detailsBill.username && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Username</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.username}</p>
                                      </div>
                                  )}
                                  {detailsBill.password && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Password</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.password}</p>
                                      </div>
                                  )}
                              </div>
                          )}
                          
                          {!detailsBill.accountNumber && !detailsBill.username && !detailsBill.password && (
                              <p className="text-xs text-slate-400 italic">No credentials shared.</p>
                          )}
                      </div>

                      {detailsBill.notes && (
                          <div className="bg-yellow-50 dark:bg-yellow-900/10 p-3 rounded-xl border border-yellow-100 dark:border-yellow-900/30">
                              <p className="text-xs font-bold text-yellow-600 dark:text-yellow-500 uppercase tracking-wider mb-1">Shared Notes</p>
                              <p className="text-sm text-slate-700 dark:text-slate-300 italic">"{detailsBill.notes}"</p>
                          </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-3 pt-2">
                          <button 
                              onClick={() => navigate('/planning')}
                              className="neo-btn flex-1 py-3 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          >
                              Edit
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Comment Modal */}
      <CommentModal 
        isOpen={!!discussingBill}
        onClose={() => setDiscussingBillId(null)}
        title={discussingBill?.name || 'Bill'}
        comments={discussingBill?.comments || []}
        onAddComment={handleAddComment}
      />

    </div>
  );
}