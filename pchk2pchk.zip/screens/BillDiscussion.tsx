import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Comment {
  id: number;
  user: string;
  avatar: string;
  time: string;
  text: string;
  isMe: boolean;
}

export default function BillDiscussion() {
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState('');
  
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      user: 'Maria',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuARR3j86vIaB3YSrtlriKAt-IztzIzMIaA1qX_jVgFlSCABTwuffx13PdgOD4rMOEjbT3h1s_Pcjdb6VXr6K6G8ILB6ZDrVhz4sH9HE0vy3S5XXe7q_Baa3Y8sUzFju2miF3hVHGIg4m8yL-7tsP7aaeEnXlTRVXFRfRDPWn6lOpaaLm9H0VARWOWAO12Z8K6qLLLalG_wWTEkTNoFerYUmJcqt3o_lNkcVwkk9F3ODxNSRzPHPszBTqoGMcACnfV9LyThw2YZ8-pI',
      time: '2h ago',
      text: 'Hey @Alex, just a reminder this is coming up. Is it all set?',
      isMe: false
    },
    {
      id: 2,
      user: 'Alex',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJ5mvAXXuPpwvDXZ7YyGz-Jauv_IExhQuvAt9loVRULPKoS5Tyi1x609wenazIuVi_w6yH0wCv2jx7u49kCwQx3HTMiP76xLDMeLeZH3u0_IOHcNPHtblXxEPo_rlQMQjnMEYTT6ZvFnADSPY0sQRzpJuJxdc4SehdqW4s-1Kv3hraUeEMApGlc5WF58khYBbQrryLsqMXeTAYs_Xmdo7sD5SWgGSuLmc5NYDkguoGj-UCvT6VmBfDcMSAFGZd_vfxeHkybwZdL4c',
      time: '1h ago',
      text: "Yep, all good! It's on autopay.",
      isMe: true
    }
  ]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBOCFvlZ58tpgrXMjatJU1I3OFUmh1LBzYPUNEkzz6QXpSs9KgfDKtlLq06vvrXF9-BRWw6jN2NhGaYaiOUNF9dbTpGwzY1eCJTOImkyZYvOQO0SB-uQPYlh5eYpJqEg5KlfnssoAt3UY_51wmWHQD9SpCVNfA1RvNs2a4i09amFKRP1JVOZPxdErC9ZINDQZRUCNTlgAIPvxA9dR-9rQzOP3jjb9UoWbCKY1duK3K31N0SrRMuRIeFEOifeiByBiKjnWnWBawJe9M',
      time: 'Just now',
      text: inputValue,
      isMe: true
    };

    setComments([...comments, newComment]);
    setInputValue('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col group/design-root overflow-x-hidden bg-background-light dark:bg-background-dark font-sans transition-colors duration-200">
      {/* Top App Bar */}
      <header className="sticky top-0 z-10 flex items-center justify-between bg-background-light dark:bg-background-dark p-4 border-b border-gray-200 dark:border-gray-700 transition-colors">
        <button onClick={() => navigate(-1)} className="flex size-10 shrink-0 items-center justify-center text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-gray-900 dark:text-white flex-1 text-center">Netflix</h1>
        <div className="size-10 shrink-0"></div>
      </header>

      <main className="flex-1 flex flex-col pb-24">
        {/* Bill Details Card */}
        <div className="bg-white dark:bg-card-dark p-4 m-4 rounded-xl shadow-sm transition-colors duration-200">
          <div className="flex items-center gap-4">
            <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-14 shrink-0" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDLYcx7sAE1t4itx78F6EJ5jos1tfbA15V3ejf1MuHVMwBWPmwuZxJPE5q3pNjuXqmWSD3Ds6Gt9vdMXCTdRlqDhrlesWc-L0PeDQoz79Iri3OKJ13ctUJtsXiaJw_D8ferydtr9gpPsLkipeKHN4OLAAcux4L6hXNTHLevs3w7UPussj3EMcaCpZY68y7fPA6EA3kcm71F2NsKx8ydBrzuuG_XUYmnRQA1WPNgerFexKw4ZZ7O8dlZ-RwxKEi-qk0ZoRQ6rfaxo8s")'}}></div>
            <div className="flex flex-col justify-center flex-1">
              <p className="text-gray-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Netflix Subscription</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm font-normal leading-normal line-clamp-2">$15.99 - Due in 5 days</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-8 w-8" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDizDSHzGtzbSgpzgmJ6eyQGVVIE55Olo0FsJ9C2CD7xGNBY8yegFp9Fs63SJJilLvErPeyDHJq4gboqoHSuLPZ5LwmdJ8eZGswIIYGyEbp3Np-pFKfx2fL5RfqNLLa0uI4rqllMrRc-IqXeIjctC-4rrFwoxEC01tlNSCrn1YYjvF3pvPSDA0iNFEE2IVFKbdBkaFAWsQXEet5bewAma5pAMF7jhKI3BTUFTgebbJF6TfyN1gi8_xos9u-JpHFWw8TSGpw8xxLBO0")'}}></div>
              <p className="text-gray-600 dark:text-gray-300 text-sm font-normal">Alex</p>
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <div className="flex-1 px-4 space-y-4">
          {comments.map((comment) => (
            <div key={comment.id} className={`flex w-full flex-row items-start justify-start gap-3 ${comment.isMe ? 'pl-12' : ''}`}>
              <div 
                className="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-10 shrink-0" 
                style={{backgroundImage: `url("${comment.avatar}")`}}
              ></div>
              <div className="flex h-full flex-1 flex-col items-start justify-start">
                <div className="flex w-full flex-row items-start justify-start gap-x-3">
                  <p className="text-gray-900 dark:text-white text-sm font-bold leading-normal tracking-[0.015em]">{comment.user}</p>
                  <p className="text-gray-500 dark:text-gray-400 text-sm font-normal leading-normal">{comment.time}</p>
                </div>
                <p className="text-gray-800 dark:text-gray-200 text-sm font-normal leading-normal" dangerouslySetInnerHTML={{
                  // Basic processing to bold mentions for demo purposes
                  __html: comment.text.replace(/@(\w+)/g, '<span class="text-primary font-medium">@$1</span>')
                }}></p>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Composer / Comment Input Bar */}
      <footer className="fixed bottom-0 max-w-[480px] w-full bg-background-light dark:bg-background-dark p-3 border-t border-gray-200 dark:border-gray-700 transition-colors">
        <div className="flex items-center gap-3">
          <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-9 shrink-0" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBOCFvlZ58tpgrXMjatJU1I3OFUmh1LBzYPUNEkzz6QXpSs9KgfDKtlLq06vvrXF9-BRWw6jN2NhGaYaiOUNF9dbTpGwzY1eCJTOImkyZYvOQO0SB-uQPYlh5eYpJqEg5KlfnssoAt3UY_51wmWHQD9SpCVNfA1RvNs2a4i09amFKRP1JVOZPxdErC9ZINDQZRUCNTlgAIPvxA9dR-9rQzOP3jjb9UoWbCKY1duK3K31N0SrRMuRIeFEOifeiByBiKjnWnWBawJe9M")'}}></div>
          <label className="flex flex-col min-w-40 h-11 flex-1">
            <div className="flex w-full flex-1 items-stretch rounded-full h-full">
              <input 
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-full text-gray-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-none bg-gray-100 dark:bg-slate-800 h-full placeholder:text-gray-500 dark:placeholder:text-gray-400 px-4 text-sm font-normal leading-normal transition-colors" 
                placeholder="Add a comment..." 
              />
            </div>
          </label>
          <button 
            onClick={handleSend}
            className="flex items-center justify-center rounded-full size-9 shrink-0 bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-50"
            disabled={!inputValue.trim()}
          >
            <span className="material-symbols-outlined text-xl">send</span>
          </button>
        </div>
      </footer>
    </div>
  );
}