import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import clsx from 'clsx';

// --- Types ---

interface User {
  id: string;
  name: string;
  avatar: string;
}

interface BillReference {
  id: number;
  name: string;
  amount: number;
  dueDate: string;
  icon: string;
}

interface Message {
  id: number;
  senderId: string;
  text: string;
  time: string;
  referencedBill?: BillReference;
  isSystem?: boolean;
}

interface ChatThread {
  id: string;
  type: 'group' | 'dm';
  name: string;
  avatar?: string; // Specific avatar for group
  participants: User[]; 
  messages: Message[];
  unreadCount?: number;
}

// --- Mock Data ---

const CURRENT_USER_ID = 'me';

const MOCK_USERS: User[] = [
  { id: 'me', name: 'You', avatar: 'https://cdn-icons-png.flaticon.com/512/149/149071.png' },
  { id: 'u1', name: 'Sarah', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBC_MI4zBQ9g7ozYOlVs6Me5WsqTHtGOh6eNlhmXu6PDQduha0EJU8B3xmv54peM-mJRXwScnA7eESYMFTfRuqqmURrinlx4OkXBeVDal6wGAmznXQUG9tYq94zZUjn1TXK6Hd-cyeC3dhR3NeQgBPo14wmV8vkTL5OCalN_1nOdddVa7s2-HW1_ZO1_Ad91YbflOYfRpl0MYs9WxVhpZ01b0pMLSdEpbQdtOuZ3oPag3qaCASIgJ72usB8wzyVyDTo3sNvvkwtGf0' },
  { id: 'u2', name: 'John', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB7_mgDSaEl36PZwAQf5C3N-S2DhJMSiEnpJMUZj2hbDDQ82lTUrSc9PwEJkSo7bnrEAZwt3qhOL5-TA1kYl9Sa9VIXcX50CFvIK9IPXl-Yu0ikjsxDUB8M07YPkPGZ-GC7uIzs1O-43nOQrYuBpNP1D3f--sJjEeugIVbOrazdqpi7DqpUSxqv1-NuUxJQbwPIRRARfX0_zW7nbAZNxT_VDei6JRqsEZ1s8ufHtkhYfmDo7CVhXjjoCtfywW6aNOcF8d4qGdkBF6Q' },
  { id: 'u3', name: 'Alex', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJ5mvAXXuPpwvDXZ7YyGz-Jauv_IExhQuvAt9loVRULPKoS5Tyi1x609wenazIuVi_w6yH0wCv2jx7u49kCwQx3HTMiP76xLDMeLeZH3u0_IOHcNPHtblXxEPo_rlQMQjnMEYTT6ZvFnADSPY0sQRzpJuJxdc4SehdqW4s-1Kv3hraUeEMApGlc5WF58khYBbQrryLsqMXeTAYs_Xmdo7sD5SWgGSuLmc5NYDkguoGj-UCvT6VmBfDcMSAFGZd_vfxeHkybwZdL4c' },
  { id: 'u4', name: 'Maria', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuARR3j86vIaB3YSrtlriKAt-IztzIzMIaA1qX_jVgFlSCABTwuffx13PdgOD4rMOEjbT3h1s_Pcjdb6VXr6K6G8ILB6ZDrVhz4sH9HE0vy3S5XXe7q_Baa3Y8sUzFju2miF3hVHGIg4m8yL-7tsP7aaeEnXlTRVXFRfRDPWn6lOpaaLm9H0VARWOWAO12Z8K6qLLLalG_wWTEkTNoFerYUmJcqt3o_lNkcVwkk9F3ODxNSRzPHPszBTqoGMcACnfV9LyThw2YZ8-pI' },
];

const AVAILABLE_BILLS: BillReference[] = [
    { id: 1, name: 'Mortgage', amount: 1500.00, dueDate: 'Oct 25', icon: 'house' },
    { id: 2, name: 'Electricity', amount: 145.20, dueDate: 'Oct 26', icon: 'bolt' },
    { id: 3, name: 'Internet', amount: 89.99, dueDate: 'Oct 29', icon: 'wifi' },
    { id: 4, name: 'Netflix', amount: 15.99, dueDate: 'Paid', icon: 'tv' },
];

const INITIAL_CHATS: ChatThread[] = [
  {
    id: 'c1',
    type: 'group',
    name: 'Group Chat',
    participants: [MOCK_USERS[0], MOCK_USERS[1], MOCK_USERS[2]],
    messages: [
      { id: 1, senderId: 'u1', text: "Just paid the electricity bill. I'll upload the receipt.", time: '10:32 AM', referencedBill: AVAILABLE_BILLS[1] },
      { id: 2, senderId: 'me', text: "Great, thanks! I'll add it to the budget.", time: '10:33 AM' },
      { id: 3, senderId: 'u2', text: "Okay, got it. Also, don't forget the internet bill is due Friday.", time: '10:35 AM', referencedBill: AVAILABLE_BILLS[2] },
      { id: 4, senderId: 'me', text: "Yep, already scheduled it!", time: '10:36 AM' }
    ],
    unreadCount: 0
  },
  {
    id: 'c2',
    type: 'dm',
    name: 'Sarah',
    participants: [MOCK_USERS[0], MOCK_USERS[1]],
    messages: [
        { id: 5, senderId: 'u1', text: "Hey, can you transfer me for the groceries?", time: 'Yesterday' }
    ],
    unreadCount: 1
  }
];

export default function FamilyChat() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Navigation State - Default to Group Chat (c1)
  const [activeChatId, setActiveChatId] = useState<string | null>('c1');
  
  // Data State with Persistence
  const [chats, setChats] = useState<ChatThread[]>(() => {
      const saved = localStorage.getItem('pchk_chats');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch(e) {
              console.error(e);
          }
      }
      return INITIAL_CHATS;
  });

  useEffect(() => {
      localStorage.setItem('pchk_chats', JSON.stringify(chats));
  }, [chats]);
  
  // Composer State
  const [inputValue, setInputValue] = useState('');
  const [showBillSelector, setShowBillSelector] = useState(false);
  const [selectedBill, setSelectedBill] = useState<BillReference | null>(null);
  
  // Mention State
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  
  // Modal State
  const [viewingBill, setViewingBill] = useState<BillReference | null>(null);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showNewChatModal, setShowNewChatModal] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const activeChat = chats.find(c => c.id === activeChatId);

  // --- Derived State ---
  
  // Users available to add to the current chat (if group)
  const usersToAdd = useMemo(() => {
      if (!activeChat) return [];
      const currentIds = activeChat.participants.map(u => u.id);
      return MOCK_USERS.filter(u => !currentIds.includes(u.id));
  }, [activeChat]);

  // Users available to mention (participants of current chat excluding me)
  const mentionableUsers = useMemo(() => {
      if (!activeChat) return [];
      return activeChat.participants.filter(u => u.id !== CURRENT_USER_ID);
  }, [activeChat]);

  // Filtered users for mention autocomplete
  const filteredMentions = useMemo(() => {
      if (mentionQuery === null) return [];
      return mentionableUsers.filter(u => u.name.toLowerCase().startsWith(mentionQuery.toLowerCase()));
  }, [mentionQuery, mentionableUsers]);

  // Group chats separation for Inbox UI
  const groupChats = chats.filter(c => c.type === 'group');
  const dmChats = chats.filter(c => c.type === 'dm');

  // --- Effects ---

  useEffect(() => {
    if (activeChatId) {
      scrollToBottom();
    }
  }, [activeChatId, chats]);

  // Handle Deep Linking from Sidebar
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const targetUserId = params.get('userId');
    const targetChatId = params.get('chatId');

    if (targetChatId) {
        setActiveChatId(targetChatId);
    } else if (targetUserId) {
        const existingChat = chats.find(c => c.type === 'dm' && c.participants.some(p => p.id === targetUserId));
        if (existingChat) {
            setActiveChatId(existingChat.id);
        } else {
            const user = MOCK_USERS.find(u => u.id === targetUserId);
            if (user) {
                startNewDm(user);
            }
        }
    }
  }, [location.search, chats]);

  const scrollToBottom = () => {
    setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  // --- Handlers ---

  const handleSendMessage = () => {
    if ((!inputValue.trim() && !selectedBill) || !activeChatId) return;

    const newMessage: Message = {
      id: Date.now(),
      senderId: CURRENT_USER_ID,
      text: inputValue,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      referencedBill: selectedBill || undefined
    };

    setChats(prev => prev.map(chat => {
        if (chat.id === activeChatId) {
            return { ...chat, messages: [...chat.messages, newMessage] };
        }
        return chat;
    }));

    setInputValue('');
    setSelectedBill(null);
    setMentionQuery(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
        if (filteredMentions.length > 0 && mentionQuery !== null) {
            // If Enter pressed while mention menu is open, select first
            selectMention(filteredMentions[0]);
            e.preventDefault();
        } else {
            handleSend();
        }
    }
  };

  const handleSend = () => {
      handleSendMessage();
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);

      // Detect @ mention
      const lastWord = val.split(' ').pop();
      if (lastWord && lastWord.startsWith('@')) {
          setMentionQuery(lastWord.substring(1));
      } else {
          setMentionQuery(null);
      }
  };

  const selectMention = (user: User) => {
      const words = inputValue.split(' ');
      words.pop(); // Remove the partial mention
      const newValue = words.join(' ') + (words.length > 0 ? ' ' : '') + `@${user.name} `;
      setInputValue(newValue);
      setMentionQuery(null);
      inputRef.current?.focus();
  };

  const handleAddUser = (user: User) => {
      if (!activeChatId) return;
      setChats(prev => prev.map(c => {
          if (c.id === activeChatId) {
              return {
                  ...c,
                  participants: [...c.participants, user],
                  messages: [...c.messages, {
                      id: Date.now(),
                      senderId: 'system',
                      text: `${user.name} was added to the group.`,
                      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      isSystem: true
                  }]
              };
          }
          return c;
      }));
      setShowAddUserModal(false);
  };

  const startNewDm = (user: User) => {
      // Check if DM exists
      const existing = chats.find(c => c.type === 'dm' && c.participants.some(p => p.id === user.id));
      if (existing) {
          setActiveChatId(existing.id);
      } else {
          const newChat: ChatThread = {
              id: `dm_${Date.now()}`,
              type: 'dm',
              name: user.name,
              participants: [MOCK_USERS.find(u => u.id === CURRENT_USER_ID)!, user],
              messages: [],
              unreadCount: 0
          };
          setChats(prev => [newChat, ...prev]);
          setActiveChatId(newChat.id);
      }
  };

  // --- Render Helpers ---

  const getChatName = (chat: ChatThread) => {
      if (chat.type === 'group') return chat.name;
      // For DM, find the other participant
      const other = chat.participants.find(p => p.id !== CURRENT_USER_ID);
      return other?.name || 'Unknown';
  };

  const getChatAvatar = (chat: ChatThread) => {
      if (chat.type === 'group') return chat.avatar;
      const other = chat.participants.find(p => p.id !== CURRENT_USER_ID);
      return other?.avatar;
  };

  const getLastMessage = (chat: ChatThread) => {
      const last = chat.messages[chat.messages.length - 1];
      if (!last) return 'No messages yet';
      if (last.text) return last.text;
      if (last.referencedBill) return `Shared bill: ${last.referencedBill.name}`;
      return '';
  };

  // --- Views ---

  if (!activeChatId) {
      // --- INBOX VIEW ---
      return (
        <div className="relative flex h-screen w-full flex-col bg-background-light dark:bg-background-dark font-sans text-slate-900 dark:text-white transition-colors duration-200">
            {/* Inbox Header */}
            <div className="flex items-center bg-background-light/95 dark:bg-background-dark/95 p-4 pb-2 justify-between border-b border-gray-200 dark:border-gray-800 shrink-0 transition-colors backdrop-blur-md z-20">
                <button onClick={() => navigate(-1)} className="neo-btn flex size-9 shrink-0 items-center justify-center rounded-full text-slate-500 md:hidden">
                    <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
                </button>
                <h1 className="text-xl font-bold leading-tight flex-1 text-center md:text-left md:pl-2">Messages</h1>
                <button 
                    onClick={() => setShowNewChatModal(true)}
                    className="neo-btn-primary size-9 flex items-center justify-center rounded-full shadow-lg active:scale-95 transition-all"
                >
                    <span className="material-symbols-outlined text-xl">add_comment</span>
                </button>
            </div>

            {/* Structured Inbox List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                
                {/* Family Group Section (Hub) */}
                <div>
                    <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 px-1">Group Hub</h2>
                    {groupChats.map(chat => (
                        <div 
                            key={chat.id} 
                            onClick={() => setActiveChatId(chat.id)}
                            className="neo-card p-4 flex items-center gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors border-2 border-transparent hover:border-primary/20"
                        >
                            <div className="relative shrink-0">
                                <div className="size-14 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center text-primary shadow-sm">
                                    <span className="material-symbols-outlined text-3xl">groups</span>
                                </div>
                                {chat.unreadCount ? (
                                    <div className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold size-5 flex items-center justify-center rounded-full border-2 border-white dark:border-background-dark">
                                        {chat.unreadCount}
                                    </div>
                                ) : null}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-baseline mb-1">
                                    <h3 className="font-bold text-base text-slate-900 dark:text-white truncate">{chat.name}</h3>
                                    <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap ml-2">
                                        {chat.messages.length > 0 ? chat.messages[chat.messages.length - 1].time : ''}
                                    </span>
                                </div>
                                <p className="text-sm text-slate-600 dark:text-slate-300 truncate leading-relaxed">
                                    {getLastMessage(chat)}
                                </p>
                            </div>
                            <span className="material-symbols-outlined text-slate-300 dark:text-slate-600">chevron_right</span>
                        </div>
                    ))}
                </div>

                {/* Direct Messages Section */}
                <div>
                    <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 px-1">Direct Messages</h2>
                    <div className="flex flex-col gap-2">
                        {dmChats.map(chat => (
                            <div 
                                key={chat.id} 
                                onClick={() => setActiveChatId(chat.id)}
                                className="neo-card p-3 flex items-center gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors neo-card-hover"
                            >
                                <div className="relative shrink-0">
                                    <img src={getChatAvatar(chat)} alt={getChatName(chat)} className="size-10 rounded-full object-cover border border-white dark:border-slate-700 shadow-sm" />
                                    {chat.unreadCount ? (
                                        <div className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold size-4 flex items-center justify-center rounded-full border-2 border-white dark:border-background-dark">
                                            {chat.unreadCount}
                                        </div>
                                    ) : null}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-center mb-0.5">
                                        <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{getChatName(chat)}</h3>
                                        <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap">
                                            {chat.messages.length > 0 ? chat.messages[chat.messages.length - 1].time : ''}
                                        </span>
                                    </div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate leading-relaxed">
                                        {getLastMessage(chat)}
                                    </p>
                                </div>
                            </div>
                        ))}
                        {dmChats.length === 0 && (
                            <p className="text-xs text-slate-400 italic px-2">No active conversations.</p>
                        )}
                    </div>
                </div>

                {/* Quick Chat Section */}
                <div className="pt-2">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">Start New Chat</h4>
                    <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                        {MOCK_USERS.filter(u => u.id !== CURRENT_USER_ID).map(user => (
                            <button key={user.id} onClick={() => startNewDm(user)} className="flex flex-col items-center gap-2 min-w-[64px] group">
                                <div className="size-14 rounded-full p-[2px] border-2 border-dashed border-slate-300 dark:border-slate-600 group-hover:border-primary transition-colors">
                                    <img src={user.avatar} className="size-full rounded-full object-cover" alt={user.name} />
                                </div>
                                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 truncate w-full text-center">{user.name}</span>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* New Chat Modal */}
            {showNewChatModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
                    <div className="neo-card w-full max-w-sm overflow-hidden p-0 animate-scale-up bg-white dark:bg-card-dark">
                        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                            <h3 className="font-bold text-slate-900 dark:text-white">New Message</h3>
                            <button onClick={() => setShowNewChatModal(false)} className="neo-btn rounded-full p-1.5"><span className="material-symbols-outlined text-lg">close</span></button>
                        </div>
                        <div className="p-2 max-h-[400px] overflow-y-auto">
                            {MOCK_USERS.filter(u => u.id !== CURRENT_USER_ID).map(user => (
                                <button 
                                    key={user.id} 
                                    onClick={() => { startNewDm(user); setShowNewChatModal(false); }}
                                    className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors group"
                                >
                                    <img src={user.avatar} className="size-10 rounded-full object-cover" alt={user.name} />
                                    <span className="text-sm font-bold text-slate-900 dark:text-white flex-1 text-left">{user.name}</span>
                                    <div className="size-8 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-400 flex items-center justify-center group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                                        <span className="material-symbols-outlined text-xl">chat</span>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
      );
  }

  // --- CHAT ROOM VIEW ---
  if (activeChat) {
      return (
        <div className="relative flex h-screen w-full flex-col overflow-hidden bg-background-light dark:bg-background-dark font-sans text-slate-900 dark:text-white transition-colors duration-200">
            {/* Header */}
            <div className="flex items-center bg-white/80 dark:bg-card-dark/90 p-3 pb-2 justify-between border-b border-white/20 dark:border-white/5 shrink-0 transition-colors backdrop-blur-xl z-20 shadow-sm">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                    <button onClick={() => setActiveChatId(null)} className="flex size-9 shrink-0 items-center justify-center text-slate-800 dark:text-white hover:bg-slate-100 dark:hover:bg-white/10 rounded-full transition-colors">
                        <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
                    </button>
                    <div className="flex items-center gap-2 overflow-hidden cursor-pointer">
                        {activeChat.type === 'group' ? (
                            <div className="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0 neo-inset">
                                <span className="material-symbols-outlined text-lg">groups</span>
                            </div>
                        ) : (
                            <img src={getChatAvatar(activeChat)} className="size-9 rounded-full object-cover border border-white dark:border-slate-600 shrink-0" alt="Avatar" />
                        )}
                        <div className="truncate">
                            <h2 className="text-sm font-bold text-slate-900 dark:text-white leading-tight truncate">{getChatName(activeChat)}</h2>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                                {activeChat.type === 'group' 
                                    ? `${activeChat.participants.length} members` 
                                    : 'Active now'}
                            </p>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-1">
                    {activeChat.type === 'group' && (
                        <button 
                            onClick={() => setShowAddUserModal(true)}
                            className="flex size-9 items-center justify-center rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
                            title="Add Member"
                        >
                            <span className="material-symbols-outlined text-xl">person_add</span>
                        </button>
                    )}
                    <button className="flex size-9 items-center justify-center rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors">
                        <span className="material-symbols-outlined text-xl">more_vert</span>
                    </button>
                </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 bg-slate-50/50 dark:bg-black/20">
                <div className="flex flex-col gap-3 min-h-full justify-end">
                    {activeChat.messages.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-10 opacity-50">
                            <span className="material-symbols-outlined text-4xl mb-2">forum</span>
                            <p className="text-xs font-bold">Start the conversation</p>
                        </div>
                    )}
                    
                    {activeChat.messages.map((msg) => {
                        if (msg.isSystem) {
                            return (
                                <div key={msg.id} className="flex justify-center my-2">
                                    <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-3 py-1 rounded-full font-bold">
                                        {msg.text}
                                    </span>
                                </div>
                            );
                        }

                        const isMe = msg.senderId === CURRENT_USER_ID;
                        const sender = activeChat.participants.find(p => p.id === msg.senderId);

                        return (
                            <div key={msg.id} className={`flex items-end gap-2 ${isMe ? 'justify-end' : ''}`}>
                                {!isMe && (
                                    <div 
                                        className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-7 shrink-0 shadow-sm border border-white/20" 
                                        style={{backgroundImage: `url("${sender?.avatar}")`}}
                                    ></div>
                                )}
                                
                                <div className={`flex flex-1 flex-col gap-1 ${isMe ? 'items-end' : 'items-start'}`}>
                                    {!isMe && (
                                        <div className="flex items-baseline gap-2 ml-1">
                                            <p className="text-slate-500 dark:text-slate-400 text-[10px] font-bold">{sender?.name}</p>
                                        </div>
                                    )}
                                    
                                    <div className={clsx(
                                        "flex flex-col max-w-[85%] sm:max-w-[320px] shadow-sm backdrop-blur-sm border border-white/10",
                                        isMe 
                                        ? 'rounded-2xl rounded-br-none bg-primary text-white' 
                                        : 'rounded-2xl rounded-bl-none bg-white dark:bg-card-dark text-slate-900 dark:text-white'
                                    )}>
                                        {msg.referencedBill && (
                                            <div 
                                                onClick={() => setViewingBill(msg.referencedBill || null)}
                                                className={clsx(
                                                    "flex items-center gap-2 p-2 m-1 mb-0 rounded-xl cursor-pointer hover:brightness-95 transition-all group",
                                                    isMe ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800"
                                                )}
                                            >
                                                <div className="flex items-center justify-center size-6 rounded-full bg-white/20 backdrop-blur-md group-hover:scale-105 transition-transform">
                                                    <span className="material-symbols-outlined text-sm">{msg.referencedBill.icon}</span>
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-1">
                                                        <p className="text-[9px] font-bold opacity-80 uppercase tracking-wider">Bill</p>
                                                    </div>
                                                    <p className="text-xs font-bold truncate">{msg.referencedBill.name}</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-[10px] font-bold opacity-80">${msg.referencedBill.amount}</p>
                                                </div>
                                            </div>
                                        )}
                                        {msg.text && (
                                            <p className="text-sm font-medium leading-relaxed px-3 py-2" dangerouslySetInnerHTML={{
                                                __html: msg.text.replace(/@(\w+)/g, '<span class="font-bold underline decoration-primary/50 decoration-2">$1</span>')
                                            }} />
                                        )}
                                    </div>
                                    
                                    <p className="text-slate-400 dark:text-slate-500 text-[9px] mx-1 font-medium">{msg.time}</p>
                                </div>
                            </div>
                        );
                    })}
                    <div ref={messagesEndRef} />
                </div>
            </div>

            {/* Composer */}
            <div className="flex flex-col px-3 py-3 gap-2 bg-white/80 dark:bg-card-dark/80 border-t border-gray-200 dark:border-gray-800 sticky bottom-0 transition-colors backdrop-blur-xl z-30">
                
                {/* Mention Popover */}
                {mentionQuery !== null && filteredMentions.length > 0 && (
                    <div className="absolute bottom-full left-4 mb-2 bg-white dark:bg-card-dark rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden min-w-[160px] animate-slide-up">
                        <div className="p-2 bg-gray-50 dark:bg-white/5 border-b border-gray-100 dark:border-gray-700">
                            <span className="text-[10px] font-bold text-gray-500 uppercase">Mention</span>
                        </div>
                        {filteredMentions.map(user => (
                            <button 
                                key={user.id}
                                onClick={() => selectMention(user)}
                                className="w-full flex items-center gap-2 p-2 hover:bg-primary/10 dark:hover:bg-white/10 transition-colors text-left"
                            >
                                <img src={user.avatar} className="size-6 rounded-full object-cover" alt={user.name} />
                                <span className="text-sm font-bold text-slate-800 dark:text-white">{user.name}</span>
                            </button>
                        ))}
                    </div>
                )}

                {/* Selected Bill Chip */}
                {selectedBill && (
                    <div className="flex items-center justify-between bg-primary/10 dark:bg-primary/20 border border-primary/20 p-2 px-3 rounded-lg animate-fade-in">
                        <div className="flex items-center gap-2 text-primary">
                            <span className="material-symbols-outlined text-lg">link</span>
                            <span className="text-xs font-bold">Referencing: {selectedBill.name}</span>
                        </div>
                        <button onClick={() => setSelectedBill(null)} className="flex items-center justify-center text-slate-500 hover:text-red-500 transition-colors">
                            <span className="material-symbols-outlined text-base">close</span>
                        </button>
                    </div>
                )}

                {/* Bill Selector */}
                {showBillSelector && (
                    <div className="absolute bottom-16 left-3 right-3 bg-white/95 dark:bg-card-dark/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden animate-slide-up z-50">
                        <div className="p-2 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-gray-50/50 dark:bg-white/5">
                            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Select Bill</span>
                            <button onClick={() => setShowBillSelector(false)} className="text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined text-base">close</span></button>
                        </div>
                        <div className="max-h-48 overflow-y-auto p-1">
                            {AVAILABLE_BILLS.map(bill => (
                                <button 
                                    key={bill.id} 
                                    onClick={() => { setSelectedBill(bill); setShowBillSelector(false); }}
                                    className="w-full flex items-center gap-2 p-2 hover:bg-primary/10 dark:hover:bg-white/10 rounded-lg transition-colors group"
                                >
                                    <div className="size-7 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center text-gray-600 dark:text-gray-300 group-hover:bg-primary group-hover:text-white transition-colors">
                                        <span className="material-symbols-outlined text-sm">{bill.icon}</span>
                                    </div>
                                    <div className="text-left flex-1">
                                        <p className="text-xs font-bold text-slate-900 dark:text-white">{bill.name}</p>
                                        <p className="text-[10px] text-slate-500 dark:text-slate-400">${bill.amount} • {bill.dueDate}</p>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                <div className="flex items-end gap-2">
                    <button 
                        onClick={() => setShowBillSelector(!showBillSelector)}
                        className={clsx(
                            "flex items-center justify-center size-10 rounded-xl shrink-0 transition-all border",
                            showBillSelector || selectedBill 
                                ? "bg-primary text-white border-primary shadow-lg shadow-primary/30" 
                                : "bg-gray-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-transparent hover:bg-gray-200 dark:hover:bg-slate-700"
                        )}
                    >
                        <span className="material-symbols-outlined text-xl">receipt_long</span>
                    </button>

                    <label className="flex flex-col min-w-0 flex-1">
                        <input 
                            ref={inputRef}
                            value={inputValue}
                            onChange={handleInputChange}
                            onKeyDown={handleKeyDown}
                            className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-none bg-gray-100 dark:bg-slate-800 focus:bg-white dark:focus:bg-black backdrop-blur-sm placeholder:text-gray-500 dark:placeholder:text-gray-400 px-4 py-2.5 text-sm font-medium leading-normal transition-all" 
                            placeholder={selectedBill ? "Add a message..." : "Message... (type @ to mention)"} 
                        />
                    </label>
                    
                    <button 
                        onClick={handleSend}
                        className="flex items-center justify-center size-10 rounded-xl bg-primary text-white shrink-0 hover:bg-primary/90 transition-all shadow-lg shadow-primary/20 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                        disabled={!inputValue.trim() && !selectedBill}
                    >
                        <span className="material-symbols-outlined text-lg">send</span>
                    </button>
                </div>
            </div>

            {/* Add User Modal */}
            {showAddUserModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
                    <div className="neo-card w-full max-w-sm overflow-hidden p-0 animate-scale-up bg-white dark:bg-card-dark">
                        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                            <h3 className="font-bold text-slate-900 dark:text-white">Add Member</h3>
                            <button onClick={() => setShowAddUserModal(false)} className="neo-btn rounded-full p-1.5"><span className="material-symbols-outlined text-lg">close</span></button>
                        </div>
                        <div className="p-2 max-h-[300px] overflow-y-auto">
                            {usersToAdd.length === 0 ? (
                                <p className="text-center text-sm text-gray-500 py-6">All available members are already in this chat.</p>
                            ) : (
                                usersToAdd.map(user => (
                                    <button 
                                        key={user.id} 
                                        onClick={() => handleAddUser(user)}
                                        className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors group"
                                    >
                                        <img src={user.avatar} className="size-10 rounded-full object-cover" alt={user.name} />
                                        <span className="text-sm font-bold text-slate-900 dark:text-white flex-1 text-left">{user.name}</span>
                                        <div className="size-8 rounded-full bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                                            <span className="material-symbols-outlined text-xl">add</span>
                                        </div>
                                    </button>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Viewing Bill Modal (Reuse) */}
            {viewingBill && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
                    <div className="neo-card w-full max-w-sm overflow-hidden p-5 animate-slide-up sm:animate-none bg-white dark:bg-card-dark">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="neo-inset flex items-center justify-center rounded-full size-10 text-primary bg-primary/10">
                                    <span className="material-symbols-outlined text-xl">{viewingBill.icon}</span>
                                </div>
                                <div>
                                    <h3 className="font-bold text-slate-900 dark:text-white text-base">{viewingBill.name}</h3>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Referenced Bill</p>
                                </div>
                            </div>
                            <button onClick={() => setViewingBill(null)} className="neo-btn rounded-full p-1.5 transition-colors">
                                <span className="material-symbols-outlined text-lg">close</span>
                            </button>
                        </div>

                        <div className="flex flex-col items-center justify-center py-4 mb-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-white/5 rounded-xl">
                            <p className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">${viewingBill.amount.toFixed(2)}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">Due {viewingBill.dueDate}</p>
                        </div>

                        <button 
                            onClick={() => { setViewingBill(null); navigate('/bills'); }} 
                            className="neo-btn-primary w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95"
                        >
                            <span>Go to Payments</span>
                            <span className="material-symbols-outlined text-base">arrow_forward</span>
                        </button>
                    </div>
                </div>
            )}
        </div>
      );
  }

  // Fallback
  return null;
}