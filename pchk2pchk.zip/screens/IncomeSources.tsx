import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';

interface IncomeSource {
  id: number;
  name: string;
  amount: number;
  // Frequency Display Text
  frequencyDisplay: string;
  // Storing complex recurrence data
  recurrence: {
      type: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
      customInterval?: number;
      customUnit?: 'day' | 'week' | 'month' | 'year';
      customDaysOfWeek?: number[]; // 0 = Sun, 1 = Mon...
  };
  nextPayday: string; // YYYY-MM-DD
  icon: string;
}

const MOCK_SOURCES: IncomeSource[] = [
    {
      id: 1,
      name: "Dad's Salary",
      amount: 2250.00,
      frequencyDisplay: "Bi-weekly",
      recurrence: { type: 'custom', customInterval: 2, customUnit: 'week' },
      nextPayday: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      icon: "payments"
    },
    {
      id: 2,
      name: "Mom's Freelance",
      amount: 800.00,
      frequencyDisplay: "Monthly",
      recurrence: { type: 'monthly' },
      nextPayday: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      icon: "work"
    },
];

export default function IncomeSources() {
  const navigate = useNavigate();
  
  // State for Income Sources with Persistence
  const [sources, setSources] = useState<IncomeSource[]>(() => {
      const saved = localStorage.getItem('pchk_income_sources');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch(e) {
              console.error(e);
          }
      }
      return MOCK_SOURCES;
  });

  useEffect(() => {
      localStorage.setItem('pchk_income_sources', JSON.stringify(sources));
  }, [sources]);

  // Modal & Form State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'view' | 'edit'>('view');
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [nextPayday, setNextPayday] = useState('');

  // Frequency Logic State
  const [recurrenceType, setRecurrenceType] = useState<'daily' | 'weekly' | 'bi-weekly' | 'monthly' | 'yearly' | 'custom'>('monthly');
  const [customInterval, setCustomInterval] = useState(1);
  const [customUnit, setCustomUnit] = useState<'day' | 'week' | 'month' | 'year'>('week');
  const [customDays, setCustomDays] = useState<number[]>([]); // 0-6

  // Payday Modal States
  const [showPaydayModal, setShowPaydayModal] = useState(false);
  const [paydayConfirmationText, setPaydayConfirmationText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Handlers
  const handleAddClick = () => {
    setEditingId(null);
    setModalMode('edit');
    setName('');
    setAmount('');
    setNextPayday(new Date().toISOString().split('T')[0]);
    
    // Reset Frequency Defaults
    setRecurrenceType('monthly');
    setCustomInterval(1);
    setCustomUnit('week');
    setCustomDays([]);
    
    setIsModalOpen(true);
  };

  const handleEditClick = (source: IncomeSource) => {
    setEditingId(source.id);
    setModalMode('view'); // Default to view
    setName(source.name);
    setAmount(source.amount.toString());
    setNextPayday(source.nextPayday);

    // Map stored recurrence to UI state
    const { type, customInterval: cInt, customUnit: cUnit, customDaysOfWeek } = source.recurrence;
    
    if (type === 'custom' && cInt === 2 && cUnit === 'week') {
         setRecurrenceType('bi-weekly');
    } else if (type === 'custom') {
         setRecurrenceType('custom');
         setCustomInterval(cInt || 1);
         setCustomUnit(cUnit || 'week');
         setCustomDays(customDaysOfWeek || []);
    } else {
         // Direct map for daily, weekly, monthly, yearly
         setRecurrenceType(type as any);
    }

    setIsModalOpen(true);
  };

  const toggleCustomDay = (dayIndex: number) => {
      if (customDays.includes(dayIndex)) {
          setCustomDays(customDays.filter(d => d !== dayIndex));
      } else {
          setCustomDays([...customDays, dayIndex]);
      }
  };

  const generateFrequencyDisplay = () => {
      if (recurrenceType === 'daily') return 'Daily';
      if (recurrenceType === 'weekly') return 'Weekly';
      if (recurrenceType === 'bi-weekly') return 'Bi-weekly';
      if (recurrenceType === 'monthly') return 'Monthly';
      if (recurrenceType === 'yearly') return 'Annually';
      
      // Custom Logic
      let text = `Every ${customInterval} ${customUnit}${customInterval > 1 ? 's' : ''}`;
      if (customUnit === 'week' && customDays.length > 0) {
          const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
          const selectedNames = customDays.sort().map(d => dayNames[d]);
          text += ` on ${selectedNames.join(', ')}`;
      }
      return text;
  };

  const handleSave = () => {
    if (!name || !amount || !nextPayday) return;

    const numAmount = parseFloat(amount);
    const frequencyDisplay = generateFrequencyDisplay();
    
    let finalRecurrence: IncomeSource['recurrence'];

    if (recurrenceType === 'bi-weekly') {
        finalRecurrence = { type: 'custom', customInterval: 2, customUnit: 'week' };
    } else if (recurrenceType === 'custom') {
        finalRecurrence = { type: 'custom', customInterval, customUnit, customDaysOfWeek: customDays };
    } else {
        finalRecurrence = { type: recurrenceType as any };
    }

    if (editingId) {
      setSources(sources.map(s => 
        s.id === editingId 
          ? { ...s, name, amount: numAmount, frequencyDisplay, recurrence: finalRecurrence, nextPayday }
          : s
      ));
    } else {
      const newSource: IncomeSource = {
        id: Date.now(),
        name,
        amount: numAmount,
        frequencyDisplay,
        recurrence: finalRecurrence,
        nextPayday,
        icon: 'attach_money'
      };
      setSources([...sources, newSource]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = () => {
    if (editingId) {
      setSources(sources.filter(s => s.id !== editingId));
      setIsModalOpen(false);
    }
  };

  const handleConfirmPayday = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsProcessing(false);
    setShowPaydayModal(false);
    setPaydayConfirmationText('');
  };

  const getPaydayStatus = (dateStr: string) => {
    if (!dateStr) return { text: '', color: '' };
    const today = new Date();
    today.setHours(0,0,0,0);
    const [year, month, day] = dateStr.split('-').map(Number);
    const target = new Date(year, month - 1, day);
    const diffTime = target.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const formattedDate = target.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    if (diffDays < 0) return { text: `Paid on ${formattedDate}`, color: 'text-gray-500' };
    if (diffDays === 0) return { text: 'Today', color: 'text-green-600 dark:text-green-400 font-bold' };
    if (diffDays === 1) return { text: 'Tomorrow', color: 'text-primary font-bold' };
    if (diffDays <= 30) return { text: `In ${diffDays} days`, color: 'text-primary font-semibold' };
    return { text: formattedDate, color: 'text-gray-500 dark:text-gray-400' };
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col font-sans bg-background-light dark:bg-background-dark transition-colors duration-200">
      <header className="sticky top-0 z-10 flex h-14 shrink-0 items-center justify-between border-b border-gray-200 dark:border-gray-700 bg-background-light/80 dark:bg-background-dark/80 px-4 backdrop-blur-sm transition-colors gap-3">
        <button onClick={() => navigate(-1)} className="flex size-9 items-center justify-start text-slate-800 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-slate-900 dark:text-white truncate">Income & Paydays</h1>
        <div className="flex items-center gap-2">
            <button 
                onClick={() => setShowPaydayModal(true)}
                className="neo-btn-primary px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95 whitespace-nowrap"
            >
                <span className="material-symbols-outlined text-lg sm:text-xl">attach_money</span>
                <span className="hidden sm:inline">I Got Paid</span>
            </button>
            {sources.length > 0 && (
                <button 
                onClick={handleAddClick}
                className="flex size-9 items-center justify-center rounded-full text-primary hover:bg-primary/10 transition-colors"
                >
                <span className="material-symbols-outlined text-2xl">add_circle</span>
                </button>
            )}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4">
        {/* List of Sources */}
        <div className="space-y-3">
          {sources.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 px-6 text-center animate-fade-in opacity-70">
                  <div className="size-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                      <span className="material-symbols-outlined text-4xl text-slate-400">wallet</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">No income sources</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 max-w-xs">Add your paychecks, side hustles, or other income streams to track paydays.</p>
                  <button 
                    onClick={handleAddClick}
                    className="neo-btn-primary px-5 py-3 rounded-xl font-bold text-sm shadow-lg"
                  >
                    Add Income Source
                  </button>
              </div>
          )}

          {sources.map((source) => {
            const status = getPaydayStatus(source.nextPayday);
            return (
              <div 
                key={source.id} 
                onClick={() => handleEditClick(source)}
                className="flex items-center gap-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-card-dark p-3 shadow-sm hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors cursor-pointer active:scale-[0.99]"
              >
                <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <span className="material-symbols-outlined text-xl">{source.icon}</span>
                </div>
                <div className="flex-1">
                  <p className="font-bold text-sm text-slate-900 dark:text-white">{source.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Next:</span>
                    <span className={clsx("text-xs font-medium", status.color)}>{status.text}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-sm text-slate-900 dark:text-white">${source.amount.toLocaleString('en-US', {minimumFractionDigits: 0})}</p>
                  <p className="text-[10px] text-gray-500 dark:text-gray-400 uppercase tracking-wide">{source.frequencyDisplay}</p>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* View/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center bg-black/50 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
          <div className="w-full max-w-md rounded-t-2xl sm:rounded-2xl bg-white dark:bg-card-dark p-6 shadow-xl transform transition-transform animate-slide-up sm:animate-none max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {modalMode === 'view' ? 'Income Details' : (editingId ? 'Edit Income' : 'Add Income')}
              </h2>
              <div className="flex items-center gap-2">
                   {modalMode === 'view' && (
                        <button onClick={() => setModalMode('edit')} className="neo-btn rounded-full p-2 text-primary hover:text-primary/80">
                            <span className="material-symbols-outlined">edit</span>
                        </button>
                    )}
                  <button onClick={() => setIsModalOpen(false)} className="rounded-full p-1 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-gray-400">
                    <span className="material-symbols-outlined">close</span>
                  </button>
              </div>
            </div>

            {modalMode === 'view' ? (
                 <div className="space-y-6 animate-fade-in">
                     <div className="flex flex-col items-center justify-center py-4">
                         <div className="neo-inset flex items-center justify-center size-16 rounded-full text-green-500 dark:text-green-400 mb-3 bg-green-50 dark:bg-green-900/10">
                             <span className="material-symbols-outlined text-3xl">payments</span>
                         </div>
                         <h3 className="text-xl font-bold text-slate-900 dark:text-white">{name}</h3>
                         <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">${parseFloat(amount || '0').toFixed(2)}</p>
                     </div>
                     <div className="grid grid-cols-2 gap-4">
                         <div className="neo-card p-3 flex flex-col items-center justify-center">
                             <span className="text-[10px] text-slate-400 uppercase font-bold">Frequency</span>
                             <span className="font-bold text-sm text-slate-800 dark:text-white mt-1 text-center">{generateFrequencyDisplay()}</span>
                         </div>
                         <div className="neo-card p-3 flex flex-col items-center justify-center">
                             <span className="text-[10px] text-slate-400 uppercase font-bold">Next Payday</span>
                             <span className="font-bold text-sm text-slate-800 dark:text-white mt-1">
                                {new Date(nextPayday).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                             </span>
                         </div>
                     </div>
                 </div>
            ) : (
                // Edit Mode Form
                <div className="space-y-4 animate-fade-in">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wider">Source Name</label>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Salary, Freelance" className="neo-inset w-full rounded-lg px-3 py-3 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-primary text-sm font-medium"/>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wider">Amount ($)</label>
                        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="neo-inset w-full rounded-lg px-3 py-3 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-primary text-sm font-medium"/>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wider">Frequency</label>
                        <div className="neo-inset px-3 rounded-lg bg-gray-50 dark:bg-slate-800">
                            <select value={recurrenceType} onChange={(e) => setRecurrenceType(e.target.value as any)} className="w-full py-3 bg-transparent text-slate-900 dark:text-white focus:outline-none border-none [&>option]:bg-white [&>option]:text-slate-900 dark:[&>option]:bg-slate-800 dark:[&>option]:text-white text-sm font-medium">
                                <option value="weekly">Weekly</option>
                                <option value="bi-weekly">Bi-weekly (Every 2 weeks)</option>
                                <option value="monthly">Monthly</option>
                                <option value="yearly">Annually</option>
                                <option value="custom">Custom...</option>
                            </select>
                        </div>
                    </div>
                     <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wider">Next Payday</label>
                        <input type="date" value={nextPayday} onChange={(e) => setNextPayday(e.target.value)} className="neo-inset w-full rounded-lg px-3 py-3 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-primary text-sm font-medium"/>
                    </div>
                    <div className="mt-8 flex gap-3">
                        {editingId && (
                            <button onClick={handleDelete} className="px-4 py-2.5 rounded-xl border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 font-bold hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-sm">Delete</button>
                        )}
                        <div className="flex-1"></div>
                        <button onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-sm">Cancel</button>
                        <button onClick={handleSave} className="px-5 py-2.5 rounded-xl bg-primary text-white font-bold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 text-sm">Save</button>
                    </div>
                </div>
            )}
          </div>
        </div>
      )}

      {/* Payday Modal */}
      {showPaydayModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
              <div className="neo-card w-full max-w-md overflow-hidden transform transition-all scale-100 p-0 border-2 border-slate-200 dark:border-slate-700">
                  <div className="bg-emerald-500 p-8 text-white text-center relative overflow-hidden">
                       <span className="material-symbols-outlined text-9xl absolute -bottom-8 -right-8 opacity-20 rotate-12">payments</span>
                       <h2 className="text-3xl font-bold relative z-10 text-shadow-sm">Payday Routine</h2>
                       <p className="text-emerald-50 font-medium relative z-10 mt-1">Clear the board and relax.</p>
                  </div>
                  
                  <div className="p-8">
                      <div className="mb-6">
                          <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                             Type "i got paid" to confirm
                          </label>
                          <div className="neo-inset p-1">
                            <input 
                                type="text" 
                                className="neo-input w-full p-4 text-center font-bold text-lg text-slate-900 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none"
                                placeholder="i got paid"
                                value={paydayConfirmationText}
                                onChange={(e) => setPaydayConfirmationText(e.target.value)}
                            />
                          </div>
                      </div>

                      <div className="space-y-4">
                          <button 
                             onClick={handleConfirmPayday}
                             disabled={paydayConfirmationText.toLowerCase() !== 'i got paid' || isProcessing}
                             className="neo-btn-primary w-full h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
                          >
                              {isProcessing ? (
                                <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                              ) : (
                                <>
                                    <span className="material-symbols-outlined">check_circle</span>
                                    <span>Confirm Receipt</span>
                                </>
                              )}
                          </button>
                      </div>
                      <div className="mt-4 text-center">
                          <button 
                             onClick={() => setShowPaydayModal(false)}
                             disabled={isProcessing}
                             className="text-slate-500 dark:text-slate-400 font-bold text-sm hover:underline"
                          >
                              Cancel
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}