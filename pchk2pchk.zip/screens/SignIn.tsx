import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function SignIn() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // If user is already logged in, skip sign in screen
    const user = localStorage.getItem('user');
    if (user) {
        navigate('/home');
    }
  }, [navigate]);

  const handleSignIn = async () => {
    setError('');
    setIsLoading(true);

    // Test Credentials Bypass
    if (email === 'test' && password === 'test') {
        await new Promise(resolve => setTimeout(resolve, 800));
        localStorage.setItem('user', JSON.stringify({
            name: 'Test User',
            email: 'test@example.com',
            avatar: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
        }));
        navigate('/home');
        return;
    }

    if (!email || !password) {
      setError('Please enter both email and password.');
      setIsLoading(false);
      return;
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      if (email.toLowerCase().includes('error')) throw new Error('Invalid credentials.');
      
      // Fallback user for demo
      localStorage.setItem('user', JSON.stringify({
          name: 'Demo User',
          email: email,
          avatar: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
      }));
      navigate('/home');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen px-6 py-8 bg-background-light dark:bg-background-dark text-slate-900 dark:text-white transition-colors duration-200">
      <div className="flex-grow flex flex-col justify-center max-w-sm mx-auto w-full">
        <div className="mb-8 flex justify-center">
            <div className="size-20 neo-card flex items-center justify-center rounded-2xl bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-900/10">
                <span className="material-symbols-outlined text-4xl text-primary drop-shadow-sm">account_balance_wallet</span>
            </div>
        </div>

        <h1 className="text-3xl font-extrabold leading-tight text-center text-slate-800 dark:text-white drop-shadow-sm mb-2">Welcome Back</h1>
        <p className="text-slate-500 dark:text-slate-400 text-center mb-8 font-medium">Enter your details to sign in.</p>
        
        <div className="flex flex-col gap-6">
          {error && (
            <div className="flex items-center gap-2 p-4 text-sm text-red-600 bg-red-50 border border-red-100 rounded-xl shadow-sm inset-shadow">
              <span className="material-symbols-outlined text-lg">error</span>
              <span className="font-bold">{error}</span>
            </div>
          )}

          <div className="space-y-1">
            <label className="ml-1 text-xs font-bold text-slate-500 uppercase tracking-wider">Email or Username</label>
            <div className="relative">
                <input 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-4 rounded-xl bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-slate-900 dark:text-white text-base font-bold placeholder:text-gray-400 placeholder:font-medium focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors shadow-sm" 
                placeholder="user@example.com" 
                type="email" 
                />
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex justify-between items-center ml-1 mr-1">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Password</span>
              <a className="text-primary text-xs font-bold hover:underline cursor-pointer">Forgot?</a>
            </div>
            <div className="relative">
                <input 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-4 rounded-xl bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-slate-900 dark:text-white text-base font-bold placeholder:text-gray-400 placeholder:font-medium focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors shadow-sm" 
                placeholder="••••••••" 
                type="password" 
                />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 mt-10">
            <button 
                onClick={handleSignIn}
                disabled={isLoading}
                className={`neo-btn-primary w-full h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 active:scale-[0.98] transition-all ${isLoading ? 'opacity-80 grayscale' : ''}`}>
                {isLoading ? <span className="material-symbols-outlined animate-spin">progress_activity</span> : 'Sign In'}
            </button>
        </div>

        <div className="text-center mt-8">
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">
            Don't have an account?{' '}
            <button onClick={() => navigate('/register')} className="font-bold text-primary hover:text-primary-dark transition-colors">Sign Up</button>
            </p>
            <div className="mt-6 p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <p className="text-xs text-slate-400 font-mono text-center">Demo: user <b>test</b> / pass <b>test</b></p>
            </div>
        </div>
      </div>
    </div>
  );
}