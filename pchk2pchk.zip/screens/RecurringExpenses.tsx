import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import CommentModal, { Comment } from '../components/CommentModal';

interface Bill {
  id: number;
  name: string;
  amount: number;
  frequency: string;
  nextDueText: string;
  cycle: 'current' | 'next';
  paycheckLabel?: string;
  category: string;
  icon: string;
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red';
  isWarning?: boolean;
  reminder: {
    enabled: boolean;
    daysBefore: number;
    time: string;
  };
  // New fields for recurrence logic
  dueDay?: number;
  dueDayOfWeek?: string;
  comments?: Comment[];
}

const MOCK_RECURRING_BILLS: Bill[] = [
    {
      id: 1,
      name: 'Mortgage',
      amount: 1850.00,
      frequency: 'Monthly',
      nextDueText: 'Next: Oct 1, 2023',
      cycle: 'current',
      paycheckLabel: 'Oct #2',
      category: 'Housing',
      icon: 'home',
      color: 'blue',
      isWarning: false,
      reminder: { enabled: true, daysBefore: 3, time: '09:00' },
      dueDay: 1,
      comments: []
    },
    {
      id: 2,
      name: 'Electricity Bill',
      amount: 75.40,
      frequency: 'Monthly',
      nextDueText: 'Due in 2 days',
      cycle: 'current',
      paycheckLabel: 'Oct #2',
      category: 'Utilities',
      icon: 'electric_bolt',
      color: 'green',
      isWarning: true,
      reminder: { enabled: true, daysBefore: 1, time: '10:00' },
      dueDay: 26,
      comments: []
    },
    {
      id: 3,
      name: 'Streaming Service',
      amount: 15.99,
      frequency: 'Monthly',
      nextDueText: 'Next: Oct 15, 2023',
      cycle: 'current',
      paycheckLabel: 'Oct #1',
      category: 'Entertainment',
      icon: 'tv_gen',
      color: 'purple',
      isWarning: false,
      reminder: { enabled: false, daysBefore: 1, time: '09:00' },
      dueDay: 15,
      comments: []
    },
    {
      id: 4,
      name: 'Car Payment',
      amount: 450.00,
      frequency: 'Monthly',
      nextDueText: 'Next: Oct 20, 2023',
      cycle: 'next',
      paycheckLabel: 'Nov #1',
      category: 'Transport',
      icon: 'directions_car',
      color: 'orange',
      isWarning: false,
      reminder: { enabled: false, daysBefore: 2, time: '12:00' },
      dueDay: 20,
      comments: []
    }
];

export default function RecurringExpenses() {
  const navigate = useNavigate();

  // State for Bills with Persistence
  const [bills, setBills] = useState<Bill[]>(() => {
      const saved = localStorage.getItem('pchk_recurring_bills');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch(e) {
              console.error(e);
          }
      }
      return MOCK_RECURRING_BILLS;
  });

  useEffect(() => {
      localStorage.setItem('pchk_recurring_bills', JSON.stringify(bills));
  }, [bills]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Payday Modal States
  const [showPaydayModal, setShowPaydayModal] = useState(false);
  const [paydayConfirmationText, setPaydayConfirmationText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [discussingBillId, setDiscussingBillId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    amount: '',
    frequency: 'Monthly',
    nextDueText: '',
    category: '',
    icon: 'receipt',
    color: 'blue' as Bill['color'],
    reminderEnabled: false,
    reminderDaysBefore: 1,
    reminderTime: '09:00',
    dueDay: 1,
    dueDayOfWeek: 'Monday'
  });

  const handleOpenModal = (bill?: Bill) => {
    if (bill) {
      setEditingId(bill.id);
      setFormData({
        name: bill.name,
        amount: bill.amount.toString(),
        frequency: bill.frequency,
        nextDueText: bill.nextDueText,
        category: bill.category,
        icon: bill.icon,
        color: bill.color,
        reminderEnabled: bill.reminder.enabled,
        reminderDaysBefore: bill.reminder.daysBefore,
        reminderTime: bill.reminder.time,
        dueDay: bill.dueDay || 1,
        dueDayOfWeek: bill.dueDayOfWeek || 'Monday'
      });
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        amount: '',
        frequency: 'Monthly',
        nextDueText: '',
        category: '',
        icon: 'receipt',
        color: 'blue',
        reminderEnabled: false,
        reminderDaysBefore: 1,
        reminderTime: '09:00',
        dueDay: 1,
        dueDayOfWeek: 'Monday'
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!formData.name || !formData.amount) return;
    const numAmount = parseFloat(formData.amount);
    
    // Auto-generate nextDueText if empty, based on simple logic
    let nextDueText = formData.nextDueText;
    if (!nextDueText) {
       const today = new Date();
       if (formData.frequency === 'Monthly') {
           // Basic next date calc for display
           let targetMonth = today.getMonth();
           if (today.getDate() > formData.dueDay) targetMonth++;
           const date = new Date(today.getFullYear(), targetMonth, formData.dueDay);
           nextDueText = `Next: ${date.toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}`;
       } else if (formData.frequency === 'Weekly') {
           nextDueText = `Every ${formData.dueDayOfWeek}`;
       } else {
           nextDueText = 'Next: TBD';
       }
    }

    const isWarning = nextDueText.toLowerCase().includes('due in') || nextDueText.toLowerCase().includes('overdue');
    const cycle: 'current' | 'next' = Math.random() > 0.5 ? 'current' : 'next';
    const paycheckLabel = cycle === 'current' ? 'Oct #2' : 'Nov #1';

    const reminderSettings = {
      enabled: formData.reminderEnabled,
      daysBefore: formData.reminderDaysBefore,
      time: formData.reminderTime
    };

    const updatedData = {
        name: formData.name,
        amount: numAmount,
        frequency: formData.frequency,
        nextDueText,
        category: formData.category,
        icon: formData.icon,
        color: formData.color,
        isWarning,
        reminder: reminderSettings,
        dueDay: formData.dueDay,
        dueDayOfWeek: formData.dueDayOfWeek
    };

    if (editingId) {
      setBills(bills.map(b => b.id === editingId ? { ...b, ...updatedData } : b));
    } else {
      setBills([...bills, {
        id: Date.now(),
        cycle,
        paycheckLabel,
        comments: [],
        ...updatedData
      }]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = () => {
    if (editingId) {
      setBills(bills.filter(b => b.id !== editingId));
      setIsModalOpen(false);
    }
  };

  const handleConfirmPayday = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    // Logic to add balance would go here
    setIsProcessing(false);
    setShowPaydayModal(false);
    setPaydayConfirmationText('');
  };

  const handleAddComment = (text: string) => {
    if (!discussingBillId) return;
    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      text,
      timestamp: 'Just now',
      isMe: true
    };
    setBills(prev => prev.map(b => b.id === discussingBillId ? { ...b, comments: [...(b.comments || []), newComment] } : b));
  };

  const getColorClasses = (color: string, isBg: boolean) => {
    // Override old colors with primary/neutral if needed, or keep for category distinction
    // Keeping category colors but making them subtle
    const base = {
      blue: isBg ? 'bg-blue-100 dark:bg-blue-900/30' : 'text-blue-600',
      green: isBg ? 'bg-green-100 dark:bg-green-900/30' : 'text-green-600',
      purple: isBg ? 'bg-purple-100 dark:bg-purple-900/30' : 'text-purple-600',
      orange: isBg ? 'bg-orange-100 dark:bg-orange-900/30' : 'text-orange-600',
      red: isBg ? 'bg-red-100 dark:bg-red-900/30' : 'text-red-600',
    };
    return base[color as keyof typeof base] || (isBg ? 'bg-gray-100' : 'text-gray-500');
  };

  const discussingBill = bills.find(b => b.id === discussingBillId);

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col group/design-root overflow-x-hidden bg-background-light dark:bg-background-dark font-sans transition-colors duration-200">
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10 transition-colors md:p-6 md:pb-0 gap-3">
        <button onClick={() => navigate(-1)} className="neo-btn flex size-9 shrink-0 items-center justify-center text-slate-800 dark:text-white rounded-full">
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center">Recurring Bills</h2>
        <div className="flex items-center">
             <button 
                onClick={() => setShowPaydayModal(true)}
                className="neo-btn-primary px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95"
            >
                <span className="material-symbols-outlined text-lg sm:text-xl">attach_money</span>
                <span className="hidden sm:inline">I Got Paid</span>
            </button>
        </div> 
      </div>

      <main className="flex-1 px-4 py-4 space-y-3 pb-24 md:px-6">
        {bills.map((bill) => (
          <div 
            key={bill.id}
            onClick={() => handleOpenModal(bill)}
            className="neo-card neo-card-hover p-3 cursor-pointer"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={clsx("neo-inset flex items-center justify-center size-10 rounded-full", getColorClasses(bill.color, false))}>
                  <span className="material-symbols-outlined text-xl">{bill.icon}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm text-slate-900 dark:text-white leading-tight">{bill.name}</p>
                    {bill.reminder.enabled && (
                      <span className="material-symbols-outlined text-[14px] text-primary" title={`Reminder: ${bill.reminder.daysBefore} days before at ${bill.reminder.time}`}>notifications_active</span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                      {bill.frequency} • {bill.frequency === 'Monthly' ? `Day ${bill.dueDay}` : bill.frequency === 'Weekly' ? `${bill.dueDayOfWeek}` : ''}
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <div className="text-right">
                    <p className="font-bold text-base text-slate-900 dark:text-white leading-tight">${bill.amount.toLocaleString('en-US', {minimumFractionDigits: 0})}</p>
                    <p className={clsx("text-[10px] font-bold mt-0.5", bill.isWarning ? "text-red-500" : "text-slate-500 dark:text-slate-400")}>
                    {bill.nextDueText}
                    </p>
                </div>
                <button 
                    onClick={(e) => { e.stopPropagation(); setDiscussingBillId(bill.id); }}
                    className="mt-1 text-slate-400 hover:text-primary transition-colors flex items-center gap-1"
                >
                    <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                    {bill.comments && bill.comments.length > 0 && <span className="text-[10px] font-bold">{bill.comments.length}</span>}
                </button>
              </div>
            </div>
          </div>
        ))}

        {bills.length === 0 && (
            <div className="neo-inset flex flex-col items-center justify-center py-12 px-6 text-center animate-fade-in opacity-70">
                <span className="material-symbols-outlined text-4xl text-slate-400 mb-2">receipt_long</span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">No bills set up yet</h3>
                <button 
                  onClick={() => handleOpenModal()}
                  className="neo-btn-primary px-4 py-2 rounded-xl font-bold mt-2 text-sm"
                >
                  Add Your First Bill
                </button>
            </div>
        )}
      </main>

      {bills.length > 0 && (
        <div className="fixed bottom-6 right-6">
          <button 
            onClick={() => handleOpenModal()}
            className="neo-btn-primary flex size-12 items-center justify-center rounded-full shadow-lg transition-transform active:scale-95"
          >
            <span className="material-symbols-outlined text-2xl">add</span>
          </button>
        </div>
      )}

      {/* Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center bg-slate-900/60 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
          <div className="neo-card w-full max-w-sm max-h-[90vh] overflow-y-auto transform transition-transform animate-slide-up sm:animate-none p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {editingId ? 'Edit Bill' : 'New Bill'}
              </h2>
              <div className="flex items-center gap-2">
                  {editingId && (
                      <button onClick={() => setDiscussingBillId(editingId)} className="neo-btn rounded-full p-2 text-gray-500 hover:text-primary transition-colors">
                          <span className="material-symbols-outlined">chat_bubble_outline</span>
                      </button>
                  )}
                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="neo-btn rounded-full p-2 text-gray-500 dark:text-gray-400"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Bill Name</label>
                  <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} placeholder="e.g. Netflix" className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none"/>
              </div>
              <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Amount</label>
                  <input type="number" value={formData.amount} onChange={(e) => setFormData({...formData, amount: e.target.value})} placeholder="0.00" className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none"/>
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Frequency</label>
                    <div className="neo-inset px-2">
                        <select value={formData.frequency} onChange={(e) => setFormData({...formData, frequency: e.target.value})} className="neo-input w-full py-3 text-slate-900 dark:text-white text-sm font-medium bg-transparent border-none focus:outline-none">
                        <option>Monthly</option>
                        <option>Weekly</option>
                        <option>Yearly</option>
                        </select>
                    </div>
                  </div>
                  <div>
                      {formData.frequency === 'Monthly' && (
                          <>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Day of Month</label>
                            <input type="number" min="1" max="31" value={formData.dueDay} onChange={(e) => setFormData({...formData, dueDay: parseInt(e.target.value)})} className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none" placeholder="Day (1-31)"/>
                          </>
                      )}
                      {formData.frequency === 'Weekly' && (
                          <>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Day of Week</label>
                            <div className="neo-inset px-2">
                                <select value={formData.dueDayOfWeek} onChange={(e) => setFormData({...formData, dueDayOfWeek: e.target.value})} className="neo-input w-full py-3 text-slate-900 dark:text-white text-sm font-medium bg-transparent border-none focus:outline-none">
                                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(d => (
                                        <option key={d} value={d}>{d}</option>
                                    ))}
                                </select>
                            </div>
                          </>
                      )}
                      {formData.frequency === 'Yearly' && (
                           <>
                             <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Date</label>
                             <div className="neo-inset w-full p-3 text-sm text-gray-400">Date picker...</div>
                           </>
                      )}
                  </div>
              </div>

              {/* Reminders Section */}
              <div className="pt-2 border-t border-gray-100 dark:border-gray-700 mt-2">
                <div className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-2">
                        <span className="material-symbols-outlined text-slate-400">notifications</span>
                        <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Enable Reminders</label>
                    </div>
                    <button 
                        onClick={() => setFormData({...formData, reminderEnabled: !formData.reminderEnabled})}
                        className={clsx("w-10 h-6 rounded-full relative transition-colors", formData.reminderEnabled ? "bg-primary" : "bg-slate-300 dark:bg-slate-600")}
                        type="button"
                    >
                        <div className={clsx("absolute top-1 left-1 bg-white size-4 rounded-full shadow transition-transform", formData.reminderEnabled ? "translate-x-4" : "")}></div>
                    </button>
                </div>

                {formData.reminderEnabled && (
                    <div className="grid grid-cols-2 gap-4 mt-2 animate-fade-in">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Notify Me</label>
                            <div className="neo-inset flex items-center px-3 bg-transparent">
                                <input 
                                    type="number" 
                                    min="0" 
                                    max="30" 
                                    value={formData.reminderDaysBefore} 
                                    onChange={(e) => setFormData({...formData, reminderDaysBefore: parseInt(e.target.value) || 0})} 
                                    className="neo-input w-full py-3 text-slate-900 dark:text-white text-sm font-medium bg-transparent focus:outline-none"
                                />
                                <span className="text-xs text-slate-400 font-bold ml-1 whitespace-nowrap">days before</span>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">At Time</label>
                            <input 
                                type="time" 
                                value={formData.reminderTime} 
                                onChange={(e) => setFormData({...formData, reminderTime: e.target.value})} 
                                className="neo-inset w-full p-3 text-slate-900 dark:text-white text-sm font-medium focus:outline-none"
                            />
                        </div>
                    </div>
                )}
              </div>

              <div className="mt-6 flex gap-3">
                {editingId && (
                    <button onClick={handleDelete} className="neo-btn px-4 py-3 rounded-xl text-red-600 dark:text-red-400 font-bold hover:bg-red-50 dark:hover:bg-red-900/20">Delete</button>
                )}
                <div className="flex-1"></div>
                <button onClick={handleSave} className="neo-btn-primary px-6 py-3 rounded-xl font-bold">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payday Modal */}
      {showPaydayModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
              <div className="neo-card w-full max-w-md overflow-hidden transform transition-all scale-100 p-0 border-2 border-slate-200 dark:border-slate-700">
                  <div className="bg-emerald-500 p-8 text-white text-center relative overflow-hidden">
                       <span className="material-symbols-outlined text-9xl absolute -bottom-8 -right-8 opacity-20 rotate-12">payments</span>
                       <h2 className="text-3xl font-bold relative z-10 text-shadow-sm">Payday Routine</h2>
                       <p className="text-emerald-50 font-medium relative z-10 mt-1">Clear the board and relax.</p>
                  </div>
                  
                  <div className="p-8">
                      <div className="mb-6">
                          <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                             Type "i got paid" to confirm
                          </label>
                          <input 
                            type="text" 
                            className="neo-inset w-full p-4 text-center font-bold text-lg text-gray-900 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none"
                            placeholder="i got paid"
                            value={paydayConfirmationText}
                            onChange={(e) => setPaydayConfirmationText(e.target.value)}
                          />
                      </div>
                      <div className="space-y-4">
                          <button onClick={handleConfirmPayday} disabled={paydayConfirmationText.toLowerCase() !== 'i got paid' || isProcessing} className="neo-btn-primary w-full h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]">
                              {isProcessing ? (
                                <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                              ) : (
                                <>
                                    <span className="material-symbols-outlined">check_circle</span>
                                    <span>Confirm Receipt</span>
                                </>
                              )}
                          </button>
                      </div>
                      <div className="mt-4 text-center">
                          <button onClick={() => setShowPaydayModal(false)} disabled={isProcessing} className="text-slate-500 dark:text-slate-400 font-bold text-sm hover:underline">Cancel</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Comment Modal */}
      <CommentModal 
        isOpen={!!discussingBill}
        onClose={() => setDiscussingBillId(null)}
        title={discussingBill?.name || 'Bill'}
        comments={discussingBill?.comments || []}
        onAddComment={handleAddComment}
      />
    </div>
  );
}