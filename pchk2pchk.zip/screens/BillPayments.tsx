import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import CommentModal, { Comment } from '../components/CommentModal';

interface Bill {
  id: number;
  name: string;
  amount: number;
  dueDate: string; 
  dueDateIso: string;
  status: 'overdue' | 'due_soon' | 'paid' | 'upcoming';
  icon: string;
  iconBg: string;
  iconColor: string;
  avatar: string;
  category: string;
  comments: Comment[];
  cycle: 'current' | 'next' | 'previous'; 
  paycheckLabel: string;
  // Shared Fields
  companyName?: string;
  website?: string;
  username?: string;
  password?: string;
  accountNumber?: string;
  notes?: string;
}

type SortOption = 'date-asc' | 'date-desc' | 'amount-asc' | 'amount-desc';
type ViewFilter = 'Oct #2 (Current)' | 'Nov #1 (Next)' | 'History';

const MOCK_PAYMENT_BILLS: Bill[] = [
    {
      id: 1,
      name: 'Mortgage',
      companyName: 'Rocket Mortgage',
      accountNumber: '9988776655',
      amount: 1500.00,
      dueDate: 'Oct 25',
      dueDateIso: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 - 5 * 60 * 60 * 1000).toISOString(),
      status: 'overdue',
      cycle: 'current',
      paycheckLabel: 'Oct #2',
      icon: 'house',
      iconBg: 'bg-primary/10',
      iconColor: 'text-primary',
      avatar: '',
      category: 'Housing',
      comments: [
        { id: 101, user: 'System', text: 'Payment failed due to insufficient funds.', timestamp: '2 days ago', isMe: false }
      ],
      notes: 'Late fee applied if not paid by 5th'
    },
    {
      id: 2,
      name: 'Car Payment',
      companyName: 'Toyota Financial',
      website: 'https://toyotafinancial.com',
      username: 'johndoe_car',
      password: 'securePassword123',
      amount: 350.00,
      dueDate: 'Oct 30',
      dueDateIso: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000 + 5 * 60 * 60 * 1000 + 30 * 60 * 1000).toISOString(),
      status: 'due_soon',
      cycle: 'current',
      paycheckLabel: 'Oct #2',
      icon: 'directions_car',
      iconBg: 'bg-primary/10',
      iconColor: 'text-primary',
      avatar: '',
      category: 'Transport',
      comments: []
    },
    {
      id: 3,
      name: 'Netflix',
      website: 'https://netflix.com',
      amount: 15.50,
      dueDate: 'Oct 18',
      dueDateIso: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'paid',
      cycle: 'current',
      paycheckLabel: 'Oct #2',
      icon: 'tv',
      iconBg: 'bg-red-500/10',
      iconColor: 'text-red-500',
      avatar: '',
      category: 'Entertainment',
      comments: []
    },
    {
      id: 4,
      name: 'Spotify',
      companyName: 'Spotify',
      notes: 'Family plan shared with Mike and Sarah',
      amount: 10.00,
      dueDate: 'Nov 5',
      dueDateIso: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'upcoming',
      cycle: 'next',
      paycheckLabel: 'Nov #1',
      icon: 'music_note',
      iconBg: 'bg-green-500/10',
      iconColor: 'text-green-500',
      avatar: '',
      category: 'Entertainment',
      comments: []
    },
    {
      id: 5,
      name: 'Internet',
      companyName: 'Xfinity',
      website: 'https://xfinity.com',
      username: 'fam_wifi',
      password: 'password!',
      amount: 89.99,
      dueDate: 'Nov 10',
      dueDateIso: new Date(Date.now() + 17 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'upcoming',
      cycle: 'next',
      paycheckLabel: 'Nov #1',
      icon: 'wifi',
      iconBg: 'bg-purple-500/10',
      iconColor: 'text-purple-500',
      avatar: '',
      category: 'Utilities',
      comments: []
    },
    {
      id: 6,
      name: 'Rent (Prev)',
      amount: 1800.00,
      dueDate: 'Oct 01',
      dueDateIso: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'paid',
      cycle: 'previous',
      paycheckLabel: 'Oct #1',
      icon: 'house',
      iconBg: 'bg-blue-500/10',
      iconColor: 'text-blue-500',
      avatar: '',
      category: 'Housing',
      comments: []
    }
];

const CountdownTimer = ({ targetDate, status, isHeader = false }: { targetDate: string, status: 'overdue' | 'due_soon' | 'paid' | 'upcoming', isHeader?: boolean }) => {
  const [timeLeft, setTimeLeft] = useState<{d: number, h: number, m: number, s: number} | null>(null);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const target = new Date(targetDate).getTime();
      let diff = target - now;

      if (status === 'overdue') {
        diff = now - target;
      }

      if (diff < 0) diff = 0;

      setTimeLeft({
        d: Math.floor(diff / (1000 * 60 * 60 * 24)),
        h: Math.floor((diff / (1000 * 60 * 60)) % 24),
        m: Math.floor((diff / 1000 / 60) % 60),
        s: Math.floor((diff / 1000) % 60),
      });
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [targetDate, status]);

  if (!timeLeft) return null;

  const isOverdue = status === 'overdue';
  const isPaid = status === 'paid';
  if(isPaid) return null;

  if (isHeader) {
      return (
        <div className={clsx(
            "flex items-center gap-1.5 font-mono text-xs font-bold uppercase tracking-widest",
            status === 'overdue' || status === 'due_soon' ? "animate-pulse" : ""
        )}>
            <span className="material-symbols-outlined text-sm mb-0.5">
                {isOverdue ? 'history' : 'timer'}
            </span>
            <span>
                {timeLeft.d}d {timeLeft.h.toString().padStart(2, '0')}h {timeLeft.m.toString().padStart(2, '0')}m
            </span>
        </div>
      );
  }

  return null;
};

export default function BillPayments() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState<ViewFilter>('Oct #2 (Current)');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('date-asc');
  
  // Modal States
  const [confirmingBillId, setConfirmingBillId] = useState<number | null>(null);
  const [viewingDetailsBillId, setViewingDetailsBillId] = useState<number | null>(null);
  const [actualPayAmount, setActualPayAmount] = useState<string>(''); 

  const [isPayAllModalOpen, setIsPayAllModalOpen] = useState(false);
  const [payAllConfirmationText, setPayAllConfirmationText] = useState('');

  const [discussingBillId, setDiscussingBillId] = useState<number | null>(null);
  const [showPaydayModal, setShowPaydayModal] = useState(false);
  const [paydayConfirmationText, setPaydayConfirmationText] = useState('');
  
  const [isProcessing, setIsProcessing] = useState(false);

  // Persistent State for Bills
  const [bills, setBills] = useState<Bill[]>(() => {
      const saved = localStorage.getItem('pchk_bill_payments');
      if (saved) {
          try {
              return JSON.parse(saved);
          } catch(e) {
              console.error(e);
          }
      }
      return MOCK_PAYMENT_BILLS;
  });

  useEffect(() => {
      localStorage.setItem('pchk_bill_payments', JSON.stringify(bills));
  }, [bills]);

  useEffect(() => {
    if (filter === 'History') {
      setSortOption('date-desc');
    } else {
      setSortOption('date-asc');
    }
  }, [filter]);

  const handlePayClick = (e: React.MouseEvent, bill: Bill) => {
    e.stopPropagation();
    setConfirmingBillId(bill.id);
    setActualPayAmount(bill.amount.toFixed(2));
  };

  const handleEditBill = (billId: number) => {
      navigate('/planning'); 
  };

  const confirmPayment = async () => {
    if (!confirmingBillId) return;
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setBills(bills.map(bill => 
      bill.id === confirmingBillId ? { ...bill, status: 'paid', amount: parseFloat(actualPayAmount) || bill.amount } : bill
    ));
    setIsProcessing(false);
    setConfirmingBillId(null);
    setActualPayAmount('');
  };

  const filteredBills = bills
    .filter(bill => {
      const isSearchMatch = bill.name.toLowerCase().includes(searchQuery.toLowerCase());
      if (!isSearchMatch) return false;

      if (filter === 'Oct #2 (Current)') {
        return bill.cycle === 'current' && bill.status !== 'paid';
      }
      if (filter === 'Nov #1 (Next)') {
        return bill.cycle === 'next' && bill.status !== 'paid';
      }
      if (filter === 'History') {
        return bill.status === 'paid';
      }
      return false;
    })
    .sort((a, b) => {
        const dateA = new Date(a.dueDateIso).getTime();
        const dateB = new Date(b.dueDateIso).getTime();
        
        switch (sortOption) {
          case 'date-asc': return dateA - dateB;
          case 'date-desc': return dateB - dateA;
          case 'amount-asc': return a.amount - b.amount;
          case 'amount-desc': return b.amount - a.amount;
          default: return 0;
        }
    });

  const confirmPayAll = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    const billsToPayIds = new Set(filteredBills.map(b => b.id));
    setBills(bills.map(bill => 
      billsToPayIds.has(bill.id) ? { ...bill, status: 'paid' } : bill
    ));
    setIsProcessing(false);
    setIsPayAllModalOpen(false);
    setPayAllConfirmationText('');
  };

  const handleConfirmPayday = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsProcessing(false);
    setShowPaydayModal(false);
    setPaydayConfirmationText('');
  };

  const handleAddComment = (text: string) => {
    if (!discussingBillId) return;
    const newComment: Comment = {
      id: Date.now(),
      user: 'You',
      text,
      timestamp: 'Just now',
      isMe: true
    };
    setBills(prev => prev.map(b => b.id === discussingBillId ? { ...b, comments: [...(b.comments || []), newComment] } : b));
  };

  const handleEditComment = (id: number, newText: string) => {
    if (!discussingBillId) return;
    setBills(prev => prev.map(b => {
        if (b.id === discussingBillId) {
            return {
                ...b,
                comments: b.comments.map(c => c.id === id ? { ...c, text: newText } : c)
            };
        }
        return b;
    }));
  };

  const totalCurrentCycle = bills.filter(b => b.cycle === 'current' && b.status !== 'paid').reduce((sum, b) => sum + b.amount, 0);
  const totalNextCycle = bills.filter(b => b.cycle === 'next' && b.status !== 'paid').reduce((sum, b) => sum + b.amount, 0);
  const totalPayAllAmount = filteredBills.reduce((sum, b) => sum + b.amount, 0);

  const billToPay = bills.find(b => b.id === confirmingBillId);
  const detailsBill = bills.find(b => b.id === viewingDetailsBillId);
  const discussingBill = bills.find(b => b.id === discussingBillId);

  const getAmountDiff = () => {
      if (!billToPay || !actualPayAmount) return null;
      const expected = billToPay.amount;
      const actual = parseFloat(actualPayAmount);
      if (isNaN(actual)) return null;
      const diff = actual - expected;
      const percent = (diff / expected) * 100;
      return { diff, percent };
  };
  const diffData = getAmountDiff();

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col group/design-root overflow-x-hidden bg-background-light dark:bg-background-dark font-sans transition-colors duration-200">
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10 transition-colors md:static md:p-6 md:pb-0 gap-3">
        <div onClick={() => navigate(-1)} className="neo-btn flex size-9 shrink-0 items-center justify-center text-slate-800 dark:text-white cursor-pointer rounded-full md:hidden">
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </div>
        <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center md:text-left">Bill Payments</h1>
        <div className="flex items-center gap-2">
            <button 
                onClick={() => setShowPaydayModal(true)}
                className="neo-btn-primary px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all hover:brightness-110 active:scale-95"
            >
                <span className="material-symbols-outlined text-lg sm:text-xl">attach_money</span>
                <span className="hidden sm:inline">I Got Paid</span>
            </button>
            <div onClick={() => navigate('/planning')} className="flex w-9 items-center justify-end text-primary cursor-pointer hover:text-primary/80 transition-colors" title="Plan Paychecks">
                <span className="material-symbols-outlined text-2xl">calendar_clock</span>
            </div>
        </div>
      </div>

      <div className="flex flex-col gap-3 px-4 py-1 md:px-6 mt-4">
        <div className="neo-inset flex h-10 w-full md:w-auto items-center justify-center p-1 transition-colors">
          {(['Oct #2 (Current)', 'Nov #1 (Next)', 'History'] as ViewFilter[]).map((item) => (
            <label key={item} className={clsx(
                "flex-1 flex cursor-pointer h-full px-2 items-center justify-center overflow-hidden rounded-md text-[10px] sm:text-xs font-bold leading-normal transition-all duration-200 text-center relative",
                filter === item 
                    ? "bg-background-light dark:bg-background-dark shadow-sm text-primary" 
                    : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
            )}>
              <span className="truncate w-full text-center relative z-10">{item}</span>
              <input 
                checked={filter === item} 
                className="invisible w-0 absolute" 
                type="radio" 
                name="bill_status_filter" 
                onChange={() => setFilter(item)}
              />
            </label>
          ))}
        </div>

        <div className="flex gap-2">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="material-symbols-outlined text-gray-400 text-lg">search</span>
            </div>
            <input
              type="text"
              className="neo-inset block w-full py-2.5 pl-9 pr-3 text-sm text-slate-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all font-medium"
              placeholder="Search bills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="relative shrink-0">
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              className="neo-card h-full appearance-none py-2.5 pl-3 pr-8 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all cursor-pointer [&>option]:bg-white [&>option]:text-slate-900 dark:[&>option]:bg-slate-800 dark:[&>option]:text-white"
            >
              <option value="date-asc">Date: Earliest</option>
              <option value="date-desc">Date: Latest</option>
              <option value="amount-asc">Amount: Low</option>
              <option value="amount-desc">Amount: High</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
              <span className="material-symbols-outlined text-gray-500 text-base">sort</span>
            </div>
          </div>
        </div>
      </div>

      <div className={clsx("flex flex-col gap-2.5 px-4 py-2 pb-24 md:px-6", filter !== 'History' ? "md:grid md:grid-cols-2 lg:grid-cols-2" : "md:max-w-3xl md:mx-auto")}>
        {filteredBills.length === 0 && (
            <div className="neo-inset flex flex-col items-center justify-center py-12 px-6 rounded-xl border border-dashed border-gray-300 dark:border-gray-700 col-span-full animate-fade-in opacity-70">
                <div className="size-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4">
                     <span className="material-symbols-outlined text-4xl text-slate-300 dark:text-slate-500">
                        {filter === 'History' ? 'history_toggle_off' : 'check_circle'}
                     </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
                  {searchQuery ? "No bills match your search" : (filter === 'Oct #2 (Current)' ? "You're all clear!" : filter === 'Nov #1 (Next)' ? "No upcoming bills" : "No payment history")}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 text-center max-w-[240px]">
                    {searchQuery ? "Try checking your spelling or using different keywords." : "Bills will appear here when they are scheduled for this cycle."}
                </p>
                {!searchQuery && (
                    <button onClick={() => navigate('/planning')} className="mt-4 neo-btn px-4 py-2 rounded-lg text-xs font-bold text-primary">
                        Plan New Bill
                    </button>
                )}
            </div>
        )}

        {filteredBills.map((bill) => {
            if (filter === 'History') {
                return (
                    <div 
                        key={bill.id} 
                        onClick={() => setViewingDetailsBillId(bill.id)}
                        className="neo-card group flex items-center gap-3 p-3 hover:shadow-sm transition-all cursor-pointer"
                    >
                         <div className="flex flex-col items-center gap-1 min-w-[40px]">
                             <div className="size-2 rounded-full bg-primary/40"></div>
                             <div className="h-full w-0.5 bg-gray-200 dark:bg-gray-700"></div>
                         </div>
                         <div className="flex-1 min-w-0">
                             <div className="flex items-center justify-between mb-0.5">
                                 <h4 className="font-bold text-slate-900 dark:text-white text-sm truncate">{bill.name}</h4>
                                 <span className="font-bold text-slate-900 dark:text-white text-sm">${bill.amount.toFixed(0)}</span>
                             </div>
                             <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{bill.dueDate} • {bill.category}</p>
                         </div>
                         <div className="flex items-center" onClick={(e) => { e.stopPropagation(); setDiscussingBillId(bill.id); }}>
                             <button className="neo-btn rounded-full p-1.5 text-gray-400 hover:text-primary transition-colors">
                                 <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                             </button>
                         </div>
                    </div>
                );
            }

            return (
                <div key={bill.id} onClick={() => setViewingDetailsBillId(bill.id)} className={clsx(
                    "neo-card flex flex-col overflow-hidden relative transition-all duration-200 cursor-pointer hover:-translate-y-0.5",
                    bill.status === 'overdue' ? "border-red-500/50" : ""
                )}>
                
                {bill.status !== 'paid' && (
                        <div className={clsx("w-full py-1 flex justify-center items-center gap-2 border-b", 
                            bill.status === 'overdue' 
                                ? "bg-red-500/10 text-red-600 dark:text-red-400 border-red-200 dark:border-red-900" 
                                : bill.status === 'due_soon'
                                    ? "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-200 dark:border-orange-900"
                                    : "bg-slate-200/50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"
                        )}>
                            <CountdownTimer targetDate={bill.dueDateIso} status={bill.status} isHeader={true} />
                        </div>
                )}

                <div className="flex items-center gap-3 p-3">
                    <div className="flex items-center gap-3 w-full relative">
                        <div className={clsx("neo-btn flex items-center justify-center rounded-full shrink-0 size-10 text-primary bg-primary/5")}>
                            <span className={clsx("material-symbols-outlined text-xl")}>{bill.icon}</span>
                        </div>
                        <div className="flex flex-col justify-center flex-grow min-w-0">
                            <div className="flex items-center gap-2">
                                <p className="text-slate-900 dark:text-white text-sm font-bold leading-tight truncate">{bill.name}</p>
                                {(bill.status === 'overdue' || bill.status === 'due_soon') && (
                                     <span className="flex size-1.5 rounded-full bg-red-500 animate-pulse"></span>
                                )}
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                                <p className={clsx(
                                    "text-xs font-bold leading-normal line-clamp-1",
                                    bill.status === 'overdue' ? "text-red-500" : 
                                    bill.status === 'due_soon' ? "text-orange-500" : "text-slate-900 dark:text-white"
                                )}>
                                    ${bill.amount.toFixed(0)}
                                </p>
                                <span className="text-slate-300 text-[10px]">•</span>
                                <p className="text-[10px] text-slate-500 truncate">{bill.companyName || bill.dueDate}</p>
                            </div>
                        </div>
                        
                        <div className="flex flex-col items-end gap-2 shrink-0">
                            <div className="flex items-center gap-1.5">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); setDiscussingBillId(bill.id); }}
                                    className="neo-btn flex items-center justify-center size-8 rounded-lg text-gray-400 hover:text-primary transition-colors"
                                >
                                    <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                                </button>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); setViewingDetailsBillId(bill.id); }}
                                    className="neo-btn flex items-center justify-center size-8 rounded-lg text-gray-400 hover:text-primary transition-colors"
                                >
                                    <span className="material-symbols-outlined text-base">visibility</span>
                                </button>
                                
                                {bill.status !== 'paid' ? (
                                    <button 
                                        onClick={(e) => handlePayClick(e, bill)}
                                        className={clsx(
                                            "flex items-center justify-center rounded-lg px-3 py-1 text-xs font-bold transition-all h-8 active:scale-95",
                                            bill.status === 'overdue' 
                                                ? "neo-btn-primary" 
                                                : "neo-btn text-primary hover:text-primary/80"
                                        )}
                                    >
                                        Pay
                                    </button>
                                ) : (
                                    <div className="neo-inset px-2 py-1 rounded text-[10px] font-bold text-green-600 dark:text-green-400 flex items-center gap-1">
                                        <span className="material-symbols-outlined text-xs">check</span> Paid
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            );
        })}
      </div>

      {/* Pay All Confirmation Modal */}
      {isPayAllModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="neo-card w-full max-w-sm overflow-hidden transform transition-all scale-100 p-6">
              <div className="flex items-center gap-4 mb-6">
                 <div className="neo-inset flex items-center justify-center rounded-full size-12 text-slate-900 dark:text-white">
                    <span className="material-symbols-outlined text-2xl">checklist</span>
                 </div>
                 <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">Pay All Bills</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">{filteredBills.length} bills selected</p>
                 </div>
              </div>
              
              <p className="text-slate-600 dark:text-slate-300 mb-6 text-sm leading-relaxed">
                Total to pay: <span className="font-bold text-slate-900 dark:text-white">${totalPayAllAmount.toLocaleString('en-US', {minimumFractionDigits: 2})}</span>.
                <br/>
                Please type <span className="font-bold text-primary">i got paid</span> to confirm clearing the board.
              </p>

              <input 
                  type="text"
                  placeholder="Type 'i got paid'"
                  value={payAllConfirmationText}
                  onChange={(e) => setPayAllConfirmationText(e.target.value)}
                  className="neo-inset w-full p-3 text-center mb-6 text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-primary/50"
              />

              <div className="flex gap-3">
                <button 
                  onClick={() => !isProcessing && setIsPayAllModalOpen(false)}
                  disabled={isProcessing}
                  className="neo-btn flex-1 px-4 py-3 rounded-xl text-slate-700 dark:text-slate-300 font-bold hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmPayAll}
                  disabled={isProcessing || payAllConfirmationText.toLowerCase() !== 'i got paid'}
                  className="neo-btn-primary flex-1 px-4 py-3 rounded-xl font-bold disabled:opacity-50 flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  {isProcessing ? (
                    <>
                      <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                    </>
                  ) : (
                    'Confirm All'
                  )}
                </button>
              </div>
          </div>
        </div>
      )}

      {/* Shared Details / View Card Modal */}
      {detailsBill && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
              <div className="neo-card w-full max-w-sm overflow-hidden p-6 animate-slide-up sm:animate-none max-h-[90vh] overflow-y-auto no-scrollbar">
                  <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                          <div className={clsx("neo-inset flex items-center justify-center rounded-full size-12", "text-primary bg-primary/10")}>
                              <span className={clsx("material-symbols-outlined text-2xl")}>{detailsBill.icon}</span>
                          </div>
                          <div>
                             <h3 className="font-bold text-slate-900 dark:text-white text-lg">{detailsBill.name}</h3>
                             <p className="text-xs text-slate-500 font-bold uppercase">{detailsBill.status === 'paid' ? 'PAID' : 'DUE'}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-2">
                          <button onClick={() => { setDiscussingBillId(detailsBill.id); }} className="neo-btn rounded-full p-2 text-gray-500 hover:text-primary transition-colors">
                              <span className="material-symbols-outlined text-lg">chat_bubble_outline</span>
                          </button>
                          <button onClick={() => setViewingDetailsBillId(null)} className="neo-btn rounded-full p-2">
                              <span className="material-symbols-outlined text-xl">close</span>
                          </button>
                      </div>
                  </div>
                  
                  <div className="flex flex-col items-center justify-center py-2 mb-6 border-b border-gray-200 dark:border-gray-800">
                        <p className="text-3xl font-bold text-slate-900 dark:text-white">${detailsBill.amount.toFixed(2)}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{detailsBill.companyName || 'Bill'}</p>
                  </div>

                  <div className="space-y-5">
                      {/* Core Info Grid */}
                      <div className="grid grid-cols-2 gap-3">
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">Due Date</span>
                              <span className="font-bold text-slate-800 dark:text-white">{detailsBill.dueDate}</span>
                          </div>
                          <div className="neo-card p-3 flex flex-col items-center">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">Status</span>
                              <span className={clsx("font-bold capitalize", 
                                detailsBill.status === 'overdue' ? "text-red-500" : 
                                detailsBill.status === 'due_soon' ? "text-orange-500" : "text-slate-800 dark:text-white")}>
                                {detailsBill.status.replace('_', ' ')}
                              </span>
                          </div>
                      </div>
                      
                      {/* Shared Creds */}
                      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl space-y-3 border border-gray-100 dark:border-gray-700">
                          <div className="flex items-center gap-2 mb-2">
                              <span className="material-symbols-outlined text-slate-400 text-lg">lock</span>
                              <span className="text-xs font-bold text-slate-500 uppercase">Shared Details</span>
                          </div>
                          
                          {detailsBill.accountNumber && (
                              <div className="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-2">
                                  <p className="text-xs font-medium text-slate-500">Account #</p>
                                  <p className="font-mono font-bold text-slate-900 dark:text-white select-all">{detailsBill.accountNumber}</p>
                              </div>
                          )}
                          
                          {(detailsBill.username || detailsBill.password) && (
                              <div className="grid grid-cols-2 gap-4 pt-1">
                                  {detailsBill.username && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Username</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.username}</p>
                                      </div>
                                  )}
                                  {detailsBill.password && (
                                      <div>
                                          <p className="text-xs font-medium text-slate-500 mb-1">Password</p>
                                          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white select-all truncate">{detailsBill.password}</p>
                                      </div>
                                  )}
                              </div>
                          )}
                          
                          {!detailsBill.accountNumber && !detailsBill.username && !detailsBill.password && (
                              <p className="text-xs text-slate-400 italic">No credentials shared.</p>
                          )}
                      </div>

                      {detailsBill.notes && (
                          <div className="bg-yellow-50 dark:bg-yellow-900/10 p-3 rounded-xl border border-yellow-100 dark:border-yellow-900/30">
                              <p className="text-xs font-bold text-yellow-600 dark:text-yellow-500 uppercase tracking-wider mb-1">Shared Notes</p>
                              <p className="text-sm text-slate-700 dark:text-slate-300 italic">"{detailsBill.notes}"</p>
                          </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-3 pt-2">
                          <button 
                              onClick={() => navigate('/planning')}
                              className="neo-btn flex-1 py-3 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          >
                              Edit
                          </button>
                          {detailsBill.status !== 'paid' && (
                              <button 
                                  onClick={(e) => {
                                      setViewingDetailsBillId(null);
                                      handlePayClick(e, detailsBill);
                                  }}
                                  className="neo-btn-primary flex-1 py-3 rounded-xl font-bold"
                              >
                                  Pay Bill
                              </button>
                          )}
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Confirm Pay Modal */}
      {billToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="neo-card w-full max-w-sm overflow-hidden transform transition-all scale-100 p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className={clsx("neo-inset flex items-center justify-center rounded-full size-12", "text-primary bg-primary/10")}>
                  <span className={clsx("material-symbols-outlined text-2xl")}>{billToPay.icon}</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">{billToPay.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Confirm Payment</p>
                </div>
              </div>
              
              <div className="mb-6 space-y-4">
                  <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Expected Amount</label>
                      <p className="text-xl font-bold text-slate-900 dark:text-white">${billToPay.amount.toFixed(2)}</p>
                  </div>
                  
                  <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Actual Amount Paid</label>
                      <input 
                        type="number"
                        step="0.01"
                        value={actualPayAmount}
                        onChange={(e) => setActualPayAmount(e.target.value)}
                        className="neo-inset w-full p-3 text-lg font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                  </div>

                  {diffData && diffData.diff !== 0 && (
                      <div className={clsx(
                          "flex items-center gap-2 text-sm font-bold p-3 rounded-lg animate-fade-in",
                          diffData.diff > 0 ? "bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400" : "bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400"
                      )}>
                          <span className="material-symbols-outlined text-lg">
                              {diffData.diff > 0 ? 'trending_up' : 'trending_down'}
                          </span>
                          <span>
                              {diffData.diff > 0 ? '+' : ''}{diffData.diff.toFixed(2)} ({diffData.diff > 0 ? '+' : ''}{diffData.percent.toFixed(1)}%)
                          </span>
                      </div>
                  )}
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => !isProcessing && setConfirmingBillId(null)}
                  disabled={isProcessing}
                  className="neo-btn flex-1 px-4 py-3 rounded-xl text-slate-700 dark:text-slate-300 font-bold disabled:opacity-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmPayment}
                  disabled={isProcessing || !actualPayAmount}
                  className="neo-btn-primary flex-1 px-4 py-3 rounded-xl font-bold disabled:opacity-50 flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  {isProcessing ? (
                    <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                  ) : (
                    'Confirm'
                  )}
                </button>
              </div>
          </div>
        </div>
      )}

      {/* Payday Modal */}
      {showPaydayModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
              <div className="neo-card w-full max-w-md overflow-hidden transform transition-all scale-100 p-0 border-2 border-slate-200 dark:border-slate-700">
                  <div className="bg-emerald-500 p-8 text-white text-center relative overflow-hidden">
                       <span className="material-symbols-outlined text-9xl absolute -bottom-8 -right-8 opacity-20 rotate-12">payments</span>
                       <h2 className="text-3xl font-bold relative z-10 text-shadow-sm">Payday Routine</h2>
                       <p className="text-emerald-50 font-medium relative z-10 mt-1">Clear the board and relax.</p>
                  </div>
                  
                  <div className="p-8">
                      <div className="mb-6">
                          <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                             Type "i got paid" to confirm
                          </label>
                          <input 
                            type="text" 
                            className="neo-inset w-full p-4 text-center font-bold text-lg text-slate-900 dark:text-white placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none"
                            placeholder="i got paid"
                            value={paydayConfirmationText}
                            onChange={(e) => setPaydayConfirmationText(e.target.value)}
                          />
                      </div>
                      <div className="space-y-4">
                          <button 
                             onClick={handleConfirmPayday}
                             disabled={paydayConfirmationText.toLowerCase() !== 'i got paid' || isProcessing}
                             className="neo-btn-primary w-full h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
                          >
                              {isProcessing ? (
                                <span className="material-symbols-outlined animate-spin text-xl">progress_activity</span>
                              ) : (
                                <>
                                    <span className="material-symbols-outlined">check_circle</span>
                                    <span>Confirm Receipt</span>
                                </>
                              )}
                          </button>
                      </div>
                      <div className="mt-4 text-center">
                          <button 
                             onClick={() => setShowPaydayModal(false)}
                             disabled={isProcessing}
                             className="text-slate-500 dark:text-slate-400 font-bold text-sm hover:underline"
                          >
                              Cancel
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* Discussion Modal - Replaced with Component */}
      <CommentModal 
        isOpen={!!discussingBill}
        onClose={() => setDiscussingBillId(null)}
        title={discussingBill?.name || 'Bill'}
        comments={discussingBill?.comments || []}
        onAddComment={handleAddComment}
        onEditComment={handleEditComment}
      />
    </div>
  );
}