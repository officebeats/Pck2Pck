import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import clsx from 'clsx';

// Screen Imports
import SignIn from './screens/SignIn';
import Register from './screens/Register';
import Dashboard from './screens/Dashboard';
import RecurringExpenses from './screens/RecurringExpenses';
import FamilyChat from './screens/FamilyChat';
import Notifications from './screens/Notifications';
import BillDiscussion from './screens/BillDiscussion';
import BillPayments from './screens/BillPayments';
import IncomeSources from './screens/IncomeSources';
import MemberProfile from './screens/MemberProfile';
import Planning from './screens/Planning';
import Settings from './screens/Settings';

/**
 * Navigation configuration for the sidebar.
 */
const NavLinks = [
  { path: '/home', label: 'Home', icon: 'home' },
  { path: '/bills', label: 'Bills', icon: 'payments' },
  { path: '/planning', label: 'Planning', icon: 'calendar_clock' },
  { path: '/income', label: 'Income', icon: 'attach_money' },
  { path: '/chat', label: 'Group Chat', icon: 'forum' },
  { path: '/notifications', label: 'Alerts', icon: 'notifications' },
  { path: '/settings', label: 'Settings', icon: 'settings' },
];

interface SidebarProps {
  isDark: boolean;
  toggleTheme: () => void;
}

/**
 * Desktop Sidebar Navigation Component
 */
const Sidebar = ({ isDark, toggleTheme }: SidebarProps) => {
  const location = useLocation();
  const [user, setUser] = useState({ name: 'John Doe', avatar: 'https://cdn-icons-png.flaticon.com/512/149/149071.png' });

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Failed to parse user", e);
      }
    }
  }, []);

  return (
    <div className="hidden md:flex flex-col w-64 bg-background-light dark:bg-background-dark border-r border-slate-300 dark:border-gray-800 h-full flex-shrink-0 transition-colors duration-200 shadow-[2px_0_10px_rgba(0,0,0,0.05)] z-20">
      <div className="p-6 flex items-center gap-3">
        {/* Custom Paycheck Logo - Green */}
        <div className="relative w-10 h-7 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-900/40 border border-primary/30 rounded-lg flex items-center justify-center shrink-0 shadow-sm overflow-hidden">
            <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-primary"></div>
            <div className="flex flex-col gap-[2px] w-full pl-2.5 pr-1.5 py-[2px]">
                <div className="flex justify-between items-center">
                     <div className="h-0.5 w-3 rounded-full bg-primary/40"></div>
                     <div className="size-1.5 rounded-full bg-primary shadow-sm"></div>
                </div>
                <div className="h-[1px] w-full bg-primary/20 rounded-full"></div>
                <div className="flex justify-end">
                     <span className="text-[6px] font-bold text-primary dark:text-green-400 font-mono leading-none">$</span>
                </div>
            </div>
        </div>
        <h1 className="text-xl font-bold tracking-tight text-slate-800 dark:text-white truncate font-sans drop-shadow-sm">pchk2PCHK</h1>
      </div>

      <nav className="flex-1 px-4 space-y-2 overflow-y-auto py-2">
        {NavLinks.map((link) => {
          // Special handling for Chat link to support query params
          const isChatParent = link.path === '/chat';
          
          let isActive = location.pathname === link.path;
          
          // Refine active state logic
          if (isChatParent) {
              // Active if path is /chat AND (no search params OR search includes chatId=c1)
              // This distinguishes it from the nested DM links which have userId=...
              const isDmActive = location.search.includes('userId=');
              isActive = location.pathname === link.path && !isDmActive;
          } else {
              // Standard strict match for other links
              isActive = location.pathname === link.path && !location.search;
          }

          // Force Chat link to open Group Chat (c1) specifically
          const toPath = isChatParent ? '/chat?chatId=c1' : link.path;
          
          return (
            <div key={link.path}>
                <Link
                to={toPath}
                className={clsx(
                    "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200",
                    isActive 
                    ? "bg-slate-900 text-white shadow-[4px_4px_8px_#b8b9be,-4px_-4px_8px_#ffffff] dark:bg-gradient-to-br dark:from-card-dark dark:to-background-dark dark:text-primary dark:shadow-[4px_4px_8px_#111213,-4px_-4px_8px_#25262b] dark:border dark:border-white/5" 
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-white/5"
                )}
                >
                <span className={clsx("material-symbols-outlined text-xl transition-transform duration-200", isActive && "scale-110")}>{link.icon}</span>
                {link.label}
                </Link>
                
                {/* Nested Chats */}
                {isChatParent && (
                    <div className="flex flex-col gap-1 mt-1 ml-9 border-l-2 border-slate-300 dark:border-slate-800 pl-3">
                        <Link to="/chat?userId=u1" className={clsx("text-xs font-bold py-1 px-2 rounded-lg transition-colors flex items-center justify-between group", location.search.includes('userId=u1') ? "text-slate-900 bg-white shadow-sm dark:bg-white/5 dark:text-white" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300")}>
                            <span>Sarah</span>
                            {/* Online dot indicator */}
                            <span className="size-1.5 rounded-full bg-green-500 opacity-0 group-hover:opacity-100 transition-opacity"></span>
                        </Link>
                        <Link to="/chat?userId=u2" className={clsx("text-xs font-bold py-1 px-2 rounded-lg transition-colors flex items-center justify-between group", location.search.includes('userId=u2') ? "text-slate-900 bg-white shadow-sm dark:bg-white/5 dark:text-white" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300")}>
                            <span>John</span>
                        </Link>
                    </div>
                )}
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-300 dark:border-gray-800 space-y-3">
        <button 
          onClick={toggleTheme}
          className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-sm font-bold text-slate-700 dark:text-slate-400 neo-btn justify-between group"
        >
          <div className="flex items-center gap-3">
             <span className="material-symbols-outlined text-lg group-hover:rotate-180 transition-transform duration-500">{isDark ? 'light_mode' : 'dark_mode'}</span>
             <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>
          </div>
        </button>
        <Link to="/settings" className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/50 dark:hover:bg-white/5 cursor-pointer transition-colors border border-transparent hover:border-slate-300 dark:hover:border-gray-700">
          <img className="size-9 rounded-full bg-gray-300 object-cover shadow-sm border border-white dark:border-gray-600" src={user.avatar} alt="Profile" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{user.name}</p>
            <p className="text-xs text-slate-500 truncate">View Profile</p>
          </div>
        </Link>
      </div>
    </div>
  );
};

/**
 * Mobile Bottom Navigation Component
 */
const BottomNav = () => {
  const location = useLocation();
  const mobileTabs = [
    { path: '/home', label: 'Home', icon: 'home' },
    { path: '/bills', label: 'Bills', icon: 'payments' },
    { path: '/planning', label: 'Plan', icon: 'calendar_clock' },
    { path: '/chat', label: 'Chat', icon: 'forum' },
    { path: '/settings', label: 'Settings', icon: 'settings' },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-xl border-t border-gray-200/50 dark:border-gray-700/50 z-50 safe-area-bottom pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      <div className="flex justify-around items-center h-20 px-2 pb-2">
        {mobileTabs.map((tab) => {
          const isActive = location.pathname === tab.path;
          return (
            <Link 
              key={tab.path} 
              to={tab.path === '/chat' ? '/chat?chatId=c1' : tab.path}
              className={clsx(
                "flex flex-col items-center justify-center w-full h-full gap-1 transition-all duration-200 relative",
                isActive ? "text-primary -translate-y-1" : "text-slate-500 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
              )}
            >
              {isActive && (
                  <div className="absolute -top-3 w-8 h-1 bg-primary rounded-b-full shadow-[0_2px_8px_rgba(0,122,51,0.4)]"></div>
              )}
              <div className={clsx(
                  "p-1.5 rounded-xl transition-all duration-200",
                  isActive ? "bg-gradient-to-br from-white to-gray-100 dark:from-card-dark dark:to-black shadow-[2px_2px_5px_#bec3c9,-2px_-2px_5px_#ffffff] dark:shadow-[2px_2px_5px_#111213,-2px_-2px_5px_#25262b]" : ""
              )}>
                  <span className={clsx("material-symbols-outlined text-2xl transition-colors", isActive && "fill")}>
                    {tab.icon}
                  </span>
              </div>
              <span className={clsx("text-[10px] font-bold", isActive ? "text-primary" : "text-slate-500")}>{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

/**
 * ScrollToTop helper to reset scroll position on route change.
 */
const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

/**
 * Main App Layout and Routing Configuration
 */
function AppContent() {
  const [isDark, setIsDark] = useState(true); // Default to Dark
  const location = useLocation();
  const isAuthScreen = location.pathname === '/' || location.pathname === '/register';

  useEffect(() => {
    // Check local storage
    const theme = localStorage.getItem('theme');
    
    // Logic: Default to Dark if no pref or pref is dark. Only light if explicitly light.
    if (theme === 'light') {
      setIsDark(false);
      document.documentElement.classList.remove('dark');
    } else {
      // Default path
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    if (isDark) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDark(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDark(true);
    }
  };

  return (
    <div className="flex h-screen w-full bg-background-light dark:bg-background-dark text-slate-900 dark:text-white overflow-hidden transition-colors duration-200 font-sans selection:bg-primary/20 selection:text-primary-dark">
        
        {!isAuthScreen && (
          <Sidebar isDark={isDark} toggleTheme={toggleTheme} />
        )}

        <div className="flex-1 flex flex-col h-full overflow-hidden relative w-full">
           <div className="flex-1 overflow-y-auto w-full no-scrollbar pb-24 md:pb-0">
             <div className={clsx("w-full h-full", !isAuthScreen ? "" : "flex justify-center")}> 
               <div className={clsx("w-full transition-all duration-300", !isAuthScreen ? "max-w-7xl mx-auto" : "max-w-[480px]")}>
                  <Routes>
                    <Route path="/" element={<SignIn />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/home" element={<Dashboard />} />
                    {/* Redirect old dashboard link to home */}
                    <Route path="/dashboard" element={<Navigate to="/home" replace />} />
                    <Route path="/planning" element={<Planning />} />
                    <Route path="/recurring" element={<RecurringExpenses />} />
                    <Route path="/chat" element={<FamilyChat />} />
                    <Route path="/notifications" element={<Notifications />} />
                    <Route path="/bill-discussion" element={<BillDiscussion />} />
                    <Route path="/bills" element={<BillPayments />} />
                    <Route path="/income" element={<IncomeSources />} />
                    <Route path="/settings" element={<Settings isDark={isDark} toggleTheme={toggleTheme} />} />
                    <Route path="/member/:id" element={<MemberProfile />} />
                  </Routes>
               </div>
             </div>
           </div>
           
           {!isAuthScreen && <BottomNav />}
        </div>
      </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <ScrollToTop />
      <AppContent />
    </HashRouter>
  );
}